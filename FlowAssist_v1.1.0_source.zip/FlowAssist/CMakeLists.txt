cmake_minimum_required(VERSION 3.21)

# Geode v5 requires C++23
set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_VISIBILITY_PRESET hidden)

project(FlowAssist VERSION 1.1.0)

# ---------------------------------------------------------------------------------------------
# Platform guard. Flow Assist is built for exactly two targets:
#   * Windows, 64-bit            (Geode target "Win64")
#   * Android, ARM64 (arm64-v8a) (Geode target "Android64")
# Android 32-bit, iOS, macOS and Linux are deliberately unsupported: configuring for them stops here.
# ---------------------------------------------------------------------------------------------
if (ANDROID)
    if (NOT ANDROID_ABI STREQUAL "arm64-v8a")
        message(FATAL_ERROR "Flow Assist only supports Android ARM64 (arm64-v8a); got ANDROID_ABI='${ANDROID_ABI}'.")
    endif()
elseif (WIN32)
    if (NOT CMAKE_SIZEOF_VOID_P EQUAL 8)
        message(FATAL_ERROR "Flow Assist only supports 64-bit Windows.")
    endif()
else()
    message(FATAL_ERROR "Flow Assist only supports Windows (x64) and Android (ARM64).")
endif()

file(GLOB_RECURSE SOURCES CONFIGURE_DEPENDS src/*.cpp)

add_library(${PROJECT_NAME} SHARED ${SOURCES})

if (NOT DEFINED ENV{GEODE_SDK})
    message(FATAL_ERROR "Unable to find Geode SDK! Please define the GEODE_SDK environment variable to point to Geode")
else()
    message(STATUS "Found Geode: $ENV{GEODE_SDK}")
endif()

add_subdirectory($ENV{GEODE_SDK} ${CMAKE_CURRENT_BINARY_DIR}/geode)

# Links Geode, packages mod.json / about.md / changelog.md / logo.png into the .geode file
setup_geode_mod(${PROJECT_NAME})
