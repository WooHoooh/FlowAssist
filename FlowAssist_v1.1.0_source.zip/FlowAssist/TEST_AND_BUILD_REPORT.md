# Flow Assist 1.1.0 - build and test report

Developer **Lumin**, mod **Flow Assist**, id `lumin.flow-assist`. Based on the supplied Alternate Assist v1.0.0 source.

## 1. Real Geode builds - NOT DONE (blocker)

| Target | Result |
|---|---|
| Android ARM64 `.geode` | **Not built.** |
| Windows x64 `.geode` | **Not built.** |

Exact blocker, re-checked just before packaging: the sandbox has no network (`github.com`, `pypi.org`,
`dl.google.com` all fail), and no Geode SDK, Android NDK, clang/clang-cl, cmake, ninja or Windows SDK. A real
build needs all of them. The fixed workflow `.github/workflows/build.yml` builds both targets on GitHub.

Evidence about the baseline: the supplied `yourname_alternate-assist.geode` holds only an `android64` binary. Its
`mod.json`, `about.md`, `changelog.md` and `logo.png` are byte-identical to the supplied source and its symbols
include the `handleButton` / `update` / `setupHasCompleted` / `resetLevel` / `onQuit` hooks, so v1.0.0 compiled
for Android ARM64. It had no Windows binary. Version 1.1.0 has not been compiled by anyone yet.

## 2. Standalone checks - DONE (no Geode, no game)

| Check | Result |
|---|---|
| `tests/engine_test.cpp`, g++ 13.3 `-O2 -Wall -Wextra -Werror` | 1969 checks, 0 failed (the original code: 1481) |
| same tests, `-fsanitize=address,undefined` | 1969 checks, 0 failed, 0 sanitizer reports |
| `tests/compare_test.cpp` old vs new engine | see README "Measurements" and `reports/` |
| `tools/check_defaults.py` | OK: 15 settings, 16 code references, identity Flow Assist / Lumin / lumin.flow-assist |
| `tools/syntax_check.sh` (Shared, Hooks, Hud, main) | OK, against hand-written stand-in headers only |
| `SettingWidgets.cpp` | edits reviewed by diff only (renames + one extra branch) |
| workflow YAML | parses; no `${{{{` left |

## 3. Afterflow compatibility - by design and by model, not observed

* Hooks: same game functions as before (`handleButton`, `update`, 3 PlayLayer lifecycle). No new hook targets.
* Default mode *Yield*: with Afterflow loaded, the game sees exactly the stream it would see without Flow Assist,
  even when events are held back and re-delivered through `handleButton` (test 8f, 12 runs, identical, 0 injected).
* *Share* (experimental): backs off on re-sent input; 200 modelled runs (hold-back 1-40 ticks, 60/144 FPS) ended
  with no stuck button.
* Afterflow's source could not be opened; the model is an assumption about how such mods deliver input.
* Configurations 1-4 (each mod on/off) have **not** been run in the game.

## 4. Source files modified

`src/AssistEngine.hpp` (engine, rewritten in place), `src/Hooks.cpp`, `src/Shared.hpp`, `src/Shared.cpp`,
`src/Hud.cpp`, `src/Hud.hpp`, `src/SettingWidgets.cpp`, `src/Defaults.hpp`, `src/main.cpp`, `mod.json`,
`CMakeLists.txt`, `.github/workflows/build.yml`, `tools/check_defaults.py`, `tests/engine_test.cpp`, `README.md`,
`about.md`, `changelog.md`. New: `tests/compare_test.cpp`, `tests/baseline/AssistEngine_v1.hpp` (the old engine,
unchanged), `tests/stubs/`, `tools/syntax_check.sh`, `reports/`. Full diff: `reports/changes_vs_v1.0.0.diff`.

## 5. Bugs fixed

1. Two-finger overlapping alternation made the assist switch on and off every few clicks (never helped).
2. Frame-time noise flipped clicks and press lengths between neighbouring frames.
3. The other player's release was swallowed while assisting (dual mode, split touch).
4. A release with no finger down was swallowed (could eat input another mod re-delivered).
5. CI workflow used invalid `${{{{ }}}}` expressions (could not run); removed the unverified `sdk: given`.
6. Burst statistics were recomputed every frame while active.

## 6. Remaining limitations

See README "Known limitations". Main ones: no real build yet; nothing tested in-game or with the real Afterflow;
Share mode is experimental; periods that are not a whole number of frames stay quantised to frames.
