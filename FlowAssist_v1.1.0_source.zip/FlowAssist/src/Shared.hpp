#pragma once

#include <Geode/Geode.hpp>

#include "AssistEngine.hpp"

namespace fa {

// Monotonic clock in seconds (std::chrono::steady_clock - identical on Windows and Android).
double now();

// The engine that drives the real game, and a second one used by the "tap pad" in the settings
// page so CPS / activation can be tried out without starting a level.
Engine& gameEngine();
Engine& padEngine();
double& padLastTap();

// True when Afterflow (mod id "afterflow.prsevend") is installed and enabled. Flow Assist never touches
// Afterflow in any way; it only asks Geode whether it is loaded, so it can decide how to behave.
bool afterflowLoaded();

// Settings -> engine config. refreshConfig() re-reads the Geode settings at most every 100 ms
// (or immediately with force) and pushes them into both engines. With Afterflow loaded, the
// "Afterflow Mode" setting turns into Config::yielding ("Yield") or Config::coop ("Share").
Config readConfig();
void refreshConfig(double t, bool force = false);

// Logs once per level when co-op mode ("Share") has backed off because input was being re-sent.
void noteCoopBackoff(Engine const& engine);

// Writes every Flow Assist setting back to its default (values live in Defaults.hpp).
void resetSettingsToDefaults();

// True only for the live PlayLayer (not the editor, menus, etc.).
bool isPlayLayer(GJBaseGameLayer* layer);

// Sends a synthetic jump-button event to the game. While it runs, our own handleButton hook
// lets the event straight through (g_injecting) so it is never mistaken for a real click.
extern bool g_injecting;
void injectButton(GJBaseGameLayer* layer, bool down, bool isPlayer1);

}  // namespace fa
