# Flow Assist

By **Lumin**. A Geometry Dash [Geode](https://geode-sdk.org) mod that keeps fast clicking and two-finger
alternation at a steady rhythm, built to coexist with **Afterflow**. (Flow Assist is the continuation of the
Alternate Assist project: same engine and settings, improved. See `changelog.md`.)

Once your clicks-per-second (CPS) reach a threshold you choose, it takes over the *timing* of your clicks and
fires them evenly at a speed you choose. It stops as soon as you stop clicking, slow down, or hold the button.

Targets **only** Windows x64 and Android ARM64 (arm64-v8a). Other platforms are not built and CMake refuses to
configure for them.

---

## Status: read this first

Standalone tests and real Geode builds are different things. Here is exactly what has and has not been done.

| Item | State |
|---|---|
| Rhythm engine (`src/AssistEngine.hpp`), host tests: `tests/engine_test.cpp` | **Run: 1969 checks, 0 failed** (g++ 13.3, `-Wall -Wextra -Werror`), and again under AddressSanitizer + UBSan: 0 reports. *Standalone: no Geode, no game.* |
| Old-vs-new measurements: `tests/compare_test.cpp` | **Run** (numbers below). *A model of the game loop, not Geometry Dash.* |
| `mod.json` <-> code consistency: `tools/check_defaults.py` | **Run: OK** (15 settings, 16 code references, identity = Flow Assist / Lumin / `lumin.flow-assist`) |
| `Shared.cpp`, `Hooks.cpp`, `Hud.cpp`, `main.cpp`: `tools/syntax_check.sh` | **Run: OK**, but against *hand-written stand-in headers* (`tests/stubs`), not the real SDK. It catches typos and signature mismatches inside our own code only. |
| `SettingWidgets.cpp` | Edited (renames + one extra status label). **Not** compiled, not syntax-checked (needs a large part of the SDK). Reviewed by diff. |
| **Windows x64 `.geode`** | **NOT BUILT.** The sandbox this was written in has no network, no Geode SDK, no clang-cl/Windows SDK, no cmake. Build it with the workflow below. |
| **Android ARM64 `.geode`** | **NOT BUILT** for the same reason. The `.geode` you supplied (v1.0.0, Alternate Assist) contains an `android64` binary that matches the v1.0.0 source, which shows that code compiled for Android ARM64. **v1.1.0 has not been built.** |
| Behaviour inside Geometry Dash, and with the real Afterflow running | **NOT TESTED.** Afterflow compatibility is by design and by model (below), not observed. |

Do not call a platform supported until its CI build is green **and** the on-device checklist below has passed.

---

## What it does

1. **Measures CPS** from the time-stamped presses of the current click burst (a burst ends after a 0.6 s pause).
2. **Activates** when CPS >= *Activation CPS*, after at least 4 clicks in a row. The click that tipped it over
   becomes its first click.
3. **Holds a steady rhythm.** While active it presses and releases the button itself at
   `drive = pace + strength x (target - pace)` clicks per second, evenly spaced, where `pace` is your smoothed
   CPS. Your own presses and releases are swallowed meanwhile; they only keep the assist alive.
4. **Stops by itself** (and resyncs the game's button to your finger) when you stop clicking, slow below 75 %
   of the threshold, hold the button, press the other player's side, restart/quit, or switch the feature off.
5. **Disabled, below the threshold, or yielding to Afterflow = vanilla.** Every event is forwarded untouched.

Only the jump button is touched. Platformer left/right, menus and the editor are never affected.

### What is new in 1.1.0 (all measured on the host model, see "Measurements")

* **Frame-aware output.** Each press goes out on the frame nearest its ideal time, and each release a fixed
  number of frames later. Before, frame-time noise flipped single clicks between neighbouring frames.
* **Two-finger alternation.** Overlapping presses (one finger still down when the next lands) are recognised as
  alternation instead of a hold. Before, the assist switched itself on and off every few clicks and never helped.
* **Other player's release is never swallowed** (dual mode with split touch could leave player 2 stuck down).
* **Unexpected releases are passed on**, never swallowed (a release with no finger down cannot be yours).
* **Afterflow coexistence** (below).
* **Cheaper per-frame work while active**: burst statistics are computed once per press, not every frame.
* **Fixed CI workflow**: the old file used `${{{{ ... }}}}`, which GitHub rejects.

## Afterflow compatibility

[Afterflow](https://github.com/afterflow-gd/afterflow) (mod id `afterflow.prsevend`) is a predictive input buffer:
it simulates the next ticks, holds a press back when pressing now would kill and a later tick survives, and
delivers it later. I could not open its `src/` folder, so what follows rests on its README and on how mods of
this kind work, **not on reading its code**.

**What Flow Assist does, and does not do**

* It hooks the same game functions it always did (`GJBaseGameLayer::handleButton`, `GJBaseGameLayer::update`,
  and three `PlayLayer` lifecycle functions). It adds **no** hook on `processCommands` or `queueButton`, never calls
  Afterflow, never touches its settings or files, and does not duplicate what it does (it re-times clicks, it does
  not predict or delay them).
* The only thing it asks Geode about Afterflow is `Loader::isModLoaded("afterflow.prsevend")`.
* Every layer other than the live `PlayLayer` is passed straight through, so any detached simulation layer an
  input mod creates is never touched.

**The one real hazard.** A mod that holds input back and delivers it later through `handleButton` makes that event
reach Flow Assist's hook *again*. If Flow Assist took it for the player's own click it could swallow the very
press Afterflow just delivered. Flow Assist cannot tell the two apart from inside `handleButton`, so:

| *Afterflow Mode* setting | When Afterflow is loaded | Guarantee |
|---|---|---|
| **Yield** (default) | Flow Assist does nothing to input (HUD shows `AFTERFLOW`). | The game sees exactly the event stream it would see without Flow Assist (test 8f, including re-delivered events). Afterflow behaves as it does alone. |
| **Share** (experimental) | Both run. Flow Assist backs off on the first sign of re-sent input (a release while no finger is down): it stops owning the button, stays out for 2 s, and for the rest of the level after 3 such events. Once that has happened it ends with a release and never presses on your behalf, so a hold is dropped instead of risking a stuck button. | No stuck button in 200 modelled runs (Afterflow-style hold-back of 1-40 ticks). It may still swallow one or two re-delivered clicks before it notices. Two-finger overlapping alternation looks like re-sent input here, so it backs off. |

With Afterflow not loaded (or disabled in Geode's mod list) the setting is ignored and Flow Assist runs normally.

Not verified against the real Afterflow: please run the on-device checks marked **AF** below.

## Settings (Mods -> Flow Assist -> Settings)

| Setting | Default | Range | Meaning |
|---|---|---|---|
| Enable Flow Assist | on | | Master switch |
| Activation CPS | 8 | 3-25 | Assist starts at this click speed |
| Target CPS | 12 | 4-30 | Speed the assist aims for |
| Assistance Strength | 60 % | 0-100 % | 0 % = your own pace, 100 % = lock to Target CPS |
| Live CPS | | | Live counter + **TAP pad** to try it without a level |
| Assist Status | | | DISABLED / INACTIVE / ACTIVE (+ speed) / AFTERFLOW |
| Show HUD | on | | In-level overlay with CPS + status |
| HUD Position | Top Left | 4 corners | |
| Hold Detection (ms) | 110 | 60-250 | Button held this long = you are holding, not spamming |
| Afterflow Mode | Yield | Yield / Share | See above. Only matters when Afterflow is loaded |
| Reset to Defaults | | | Writes every default back |

The mod id changed (`yourname.alternate-assist` -> `lumin.flow-assist`), so settings saved by Alternate Assist do not carry over.

---

## Build (Windows x64 + Android ARM64)

Pinned to **Geode 5.11.2 / Geometry Dash 2.2081** in `mod.json`.

### GitHub Actions (recommended; no local toolchain)

1. Push this folder to a GitHub repo.
2. **Actions -> Build Flow Assist -> Run workflow** (it also runs on every push).
3. Download the artifacts: `flow-assist-windows-x64` and `flow-assist-android-arm64` (each holds a `.geode`).
   The `engine-tests` job runs the host tests, the sanitizer run and the comparison.

The build job uses `geode-sdk/build-geode-mod@main` the way Geode's own template does. If you want a fixed SDK
version instead of the action's default, add `sdk: v5.11.2` under `with:`.

### Local

Install the [Geode CLI](https://docs.geode-sdk.org/getting-started/geode-cli), run `geode sdk install`, then
`geode build` (Windows, Visual Studio 2022 C++ workload) or `geode build -p android64` (needs the Android NDK).

### Install

* **Windows:** copy the `.geode` into `<Geometry Dash folder>\geode\mods\`.
* **Android:** copy it to `/storage/emulated/0/Android/media/com.geode.launcher/game/geode/mods/`, restart GD.

## On-device checklist (run on BOTH platforms)

| # | Test | Pass criteria |
|---|---|---|
| 1 | Open Mods -> Flow Assist -> Settings | All controls appear (incl. Afterflow Mode); no Geode error in the log |
| 2 | Tap the TAP pad slowly, then fast | CPS tracks; INACTIVE then ACTIVE within ~4 taps; stops ~0.15 s after you stop |
| 3 | In a level (practice), one-finger spam | HUD pulses on activation; even clicks at the drive speed |
| 4 | Two-finger alternation with overlap | Status stays ACTIVE for the whole spam (it used to flicker off) |
| 5 | Spam then hold the button | Assist stops; the hold passes through |
| 6 | Disable the mod, play normally | Indistinguishable from vanilla |
| 7 | Die / restart / pause / quit mid-spam | No stuck button, no phantom click |
| 8 | 10+ minutes of play | No crash, no FPS drop |
| AF1 | Flow Assist on, Afterflow off | Full behaviour |
| AF2 | Flow Assist off, Afterflow on | Afterflow exactly as before |
| AF3 | Both on, mode **Yield** | HUD says AFTERFLOW; Afterflow behaves exactly as alone; no crash |
| AF4 | Both on, mode **Share**, spam in a tight section | No stuck button; note whether the log shows "assist paused"; report lost/extra clicks |

Collect Geode's log (`geode/logs`) for any failure.

## Where to look first if the CI build fails

1. `Hooks.cpp`: `handleButton`, `update`, `setupHasCompleted`, `resetLevel`, `onQuit` must match the 2.2081
   bindings (they are the same hooks the v1.0.0 Android build already used).
2. `Shared.cpp`: `Loader::get()->isModLoaded(...)` (new in 1.1.0) and `Mod::getSettingValue<std::string>`.
3. `SettingWidgets.cpp`: custom-setting API. `Hud.cpp`: core cocos2d classes only.

## Measurements (host model; `tests/compare_test.cpp`, old engine = `tests/baseline`)

Identical simulated input to both engines, frame times with +-8 % noise. Lower is better unless noted.

| What | Old (v1.0.0) | New (1.1.0) |
|---|---|---|
| Press-interval variation (CV), average of 13 target/FPS cases | 0.066 | **0.030** |
| ...at whole-frame periods, e.g. 12 CPS @ 60 / 144 / 240 FPS | 0.106 / 0.044 / 0.027 | **0.013 / 0.006 / 0.003** |
| ...at periods that are not a whole number of frames (13.7 CPS) | 0.110 @ 60 FPS | 0.110 (unchanged: limited by whole frames) |
| Presses with identical length in frames (higher is better) | 83.6 % (56.7 % at 12 CPS) | **100 %** |
| Two-finger overlap, 70 clicks: frames with the assist on | 0 % (switched on/off 17 times) | **81-87 %** (switched on once) |
| Spam -> hold: longest "up" seen by the game, 30 / 50 / 70 ms taps @ 60 FPS | 82.7 / 66.7 / 50.0 ms | 70.0 / 50.0 / 50.0 ms (144 FPS, 30 ms taps: +1 ms) |
| CPU per frame, assist active (240 FPS) | 25.8 ns | **15.2 ns** |
| CPU per frame, assist inactive | 10.1 ns | 10.2 ns (same) |
| CPS measurement error | 0.1-1.2 % mean | identical: a least-squares estimator was tried and **rejected** (worse with real click jitter) |

## Known limitations

* **Frame granularity.** A click can only land on a frame, so a period that is not a whole number of frames still
  alternates between two frame counts (CV about 0.05-0.11 at 60 FPS).
* **Hold latency.** While active your presses are swallowed; a deliberate hold is noticed after *Hold Detection*.
  Measured worst "up" time during that handover: 48-70 ms.
* **Overlap means alternation.** One finger holding while another taps looks the same as two-finger alternation.
* **Share mode** is experimental (see above). **Yield mode** gives up Flow Assist's function while Afterflow is loaded.
* Click timestamps are taken when GD dispatches the input (one frame of accuracy). Untested with Click Between
  Steps / Click Between Frames / macro bots.
* Only active in real levels (`PlayLayer`).
* **Fair play:** this changes your input and is tagged `cheat`. Don't use it where leaderboard or verification
  rules forbid assists.

## Reproduce the standalone checks

```
python3 tools/check_defaults.py
./tools/syntax_check.sh
g++ -std=c++20 -O2 -Wall -Wextra -Werror -I src tests/engine_test.cpp -o engine_test && ./engine_test
g++ -std=c++20 -O1 -g -fsanitize=address,undefined -I src tests/engine_test.cpp -o engine_test_san && ./engine_test_san
g++ -std=c++20 -O2 -I src -I tests tests/compare_test.cpp -o compare_test && ./compare_test
```

## Layout

```
mod.json                 Geode metadata + all settings (Geode 5.11.2, GD 2.2081, win + android only)
CMakeLists.txt           Geode v5 project, hard platform guard (Win64 / Android arm64-v8a only)
src/AssistEngine.hpp     Rhythm engine - pure C++, no Geode dependency (namespace fa)
src/Hooks.cpp            GD input hooks, per-frame injection, level start/restart/quit
src/Hud.*                In-level overlay
src/SettingWidgets.cpp   Live CPS + TAP pad, status indicator, reset button (custom settings)
src/Shared.*             Clock, engines, settings bridge, Afterflow detection, injection helper
src/Defaults.hpp         Default values (must equal mod.json)
tests/engine_test.cpp    Host tests (1969 checks)
tests/compare_test.cpp   Old-vs-new measurements;  tests/baseline = the v1.0.0 engine, unchanged
tests/stubs/             Stand-in Geode headers for tools/syntax_check.sh
tools/check_defaults.py  mod.json <-> code consistency check
.github/workflows/build.yml  CI: tests + Windows x64 + Android ARM64 .geode
```
