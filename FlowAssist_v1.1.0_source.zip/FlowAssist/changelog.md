# v1.1.0

- Renamed to **Flow Assist** (developer **Lumin**, id `lumin.flow-assist`). Continues Alternate Assist; settings from the old id do not carry over.
- Straighter output: presses land on the frame nearest their ideal time and every press has the same length in frames.
- Two-finger alternation (overlapping presses) no longer counts as a hold, so the assist stays on.
- The other player's release is never swallowed; releases nobody expected are passed on.
- Afterflow coexistence: new **Afterflow Mode** setting (Yield by default, or experimental Share), `AFTERFLOW` status in the HUD and settings page.
- Less work per frame while the assist is active.
- Fixed the GitHub Actions workflow (invalid expression syntax) and extended CI with sanitizer and comparison runs.

# v1.0.0 (as Alternate Assist)

- Initial release.
- CPS detection, threshold-activated click assist, assistance strength and target CPS.
- Settings page with live CPS counter + tap pad, status indicator and reset button.
- In-level HUD with an activation pulse.
