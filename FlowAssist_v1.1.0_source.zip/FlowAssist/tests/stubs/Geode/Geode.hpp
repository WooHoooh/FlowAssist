#pragma once
// STAND-IN for the Geode SDK, used only by tools/syntax_check.sh to catch typos, wrong member names and
// signature mismatches INSIDE Flow Assist's own code. It is hand-written from how the project uses the SDK; it
// does not prove that the real SDK has these members with these signatures. The real build is the GitHub Actions
// workflow (geode-sdk/build-geode-mod).

#include <cstdint>
#include <cstdio>
#include <memory>
#include <string>
#include <utility>

#define $modify(Name, Base) Name : public Base
#define $on_mod(Event) void geodeStandInOnMod_##Event()
#define schedule_selector(f) (&f)

namespace cocos2d {
struct CCPoint { float x = 0, y = 0; };
struct CCSize { float width = 0, height = 0; };
struct ccColor3B { unsigned char r = 0, g = 0, b = 0; };
struct ccColor4B { unsigned char r = 0, g = 0, b = 0, a = 0; };
struct ccColor4F { float r = 0, g = 0, b = 0, a = 0; };
inline ccColor3B ccc3(unsigned char r, unsigned char g, unsigned char b) { return {r, g, b}; }
inline ccColor4B ccc4(unsigned char r, unsigned char g, unsigned char b, unsigned char a) { return {r, g, b, a}; }
inline ccColor4F ccc4f(float r, float g, float b, float a) { return {r, g, b, a}; }

class CCObject {
public:
    virtual ~CCObject() = default;
    CCObject* autorelease() { return this; }
};
class CCAction : public CCObject {};
class CCActionInterval : public CCAction {};
class CCScaleTo : public CCActionInterval { public: static CCScaleTo* create(float, float) { return new CCScaleTo(); } };
class CCSequence : public CCActionInterval {
public:
    template <class... A> static CCSequence* create(CCActionInterval*, A...) { return new CCSequence(); }
};

class CCNode : public CCObject {
public:
    virtual bool init() { return true; }
    void setContentSize(CCSize) {}
    void setAnchorPoint(CCPoint) {}
    void setScale(float) {}
    void setPosition(CCPoint) {}
    void setVisible(bool) {}
    void addChild(CCNode*, int = 0) {}
    void stopAllActions() {}
    CCAction* runAction(CCAction* a) { return a; }
    template <class F> void schedule(F, float) {}
};
class CCLayerColor : public CCNode {
public:
    static CCLayerColor* create(ccColor4B, float, float) { return new CCLayerColor(); }
    void setColor(ccColor3B) {}
};
class CCDrawNode : public CCNode {
public:
    static CCDrawNode* create() { return new CCDrawNode(); }
    void clear() {}
    bool drawDot(CCPoint, float, ccColor4F) { return true; }
};
class CCLabelBMFont : public CCNode {
public:
    static CCLabelBMFont* create(char const*, char const*) { return new CCLabelBMFont(); }
    void setString(char const*) {}
    void setColor(ccColor3B) {}
};
class CCDirector {
public:
    static CCDirector* sharedDirector() { static CCDirector d; return &d; }
    CCSize getWinSize() { return {480, 320}; }
};
}  // namespace cocos2d

namespace geode {
namespace log {
template <class... A> void info(char const*, A&&...) {}
template <class... A> void warn(char const*, A&&...) {}
}  // namespace log

class Mod {
public:
    static Mod* get() { static Mod m; return &m; }
    template <class T> T getSettingValue(std::string const&) { return T{}; }
    template <class T> bool setSettingValue(std::string const&, T const&) { return true; }
};
class Loader {
public:
    static Loader* get() { static Loader l; return &l; }
    bool isModLoaded(std::string const&) const { return false; }
};

namespace prelude {
using namespace cocos2d;
using geode::Mod;
using geode::Loader;
namespace log = geode::log;
using int64_t = std::int64_t;
}  // namespace prelude
}  // namespace geode

using namespace cocos2d;

// ---- game classes -----------------------------------------------------------------------------
class GJBaseGameLayer : public cocos2d::CCNode {
public:
    void handleButton(bool, int, bool) {}
    void update(float) {}
};
class PlayLayer : public GJBaseGameLayer {
public:
    static PlayLayer* get() { return nullptr; }
    void setupHasCompleted() {}
    void resetLevel() {}
    void onQuit() {}
};
class UILayer : public cocos2d::CCNode {
public:
    static UILayer* get() { return nullptr; }
};
