// The only place that touches Geometry Dash's input path.
//
//   GJBaseGameLayer::handleButton   every real press/release of the jump button passes through here;
//                                   the engine decides whether it is forwarded or swallowed.
//   GJBaseGameLayer::update         once per frame: the engine's lifecycle checks (stopped / slowed / holding).
//   GJBaseGameLayer::processCommands once per physics tick while the assist is active: the actual clicks, on the
//                                   240 Hz tick grid (TickDrive.hpp): level flight or a steady rhythm.
//   PlayLayer::setupHasCompleted    level start: reset the engine, attach the HUD.
//   PlayLayer::resetLevel           death / restart: reset the engine, release an assist-held button.
//   PlayLayer::onQuit               leaving the level: reset the engine.
//
// Everything outside a live PlayLayer (menus, the editor, the settings page, any other layer such as a
// simulation layer another mod creates) is passed straight through, and so is every event while Flow Assist is
// disabled or yielding to Afterflow: in those states the processCommands hook does nothing but call the
// original. Flow Assist adds no hook on queueButton, and it never calls into Afterflow: the only thing it asks
// Geode about Afterflow is "is it loaded?".

#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <cstdint>

#include "AssistEngine.hpp"
#include "Hud.hpp"
#include "Shared.hpp"
#include "TickDriver.hpp"
#include "TickDrive.hpp"

using namespace geode::prelude;

namespace {

fa::Fly flyModeOf(PlayerObject* p) {
    if (p->m_isShip) return fa::Fly::Ship;
    if (p->m_isDart) return fa::Fly::Wave;
    if (p->m_isBird) return fa::Fly::Ufo;
    if (p->m_isSwing) return fa::Fly::Swing;
    return fa::Fly::None;   // cube, ball, robot, spider: plain rhythm
}

fa::TickDriver g_drive;   // only touched from the game thread

}  // namespace

class $modify(FlowBaseLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        // Not the jump button, one of our own synthetic events, or not a live level: vanilla path.
        if (button != 1 || fa::g_injecting || !fa::isPlayLayer(this)) {
            GJBaseGameLayer::handleButton(down, button, isPlayer1);
            return;
        }

        const double t = fa::now();
        fa::refreshConfig(t);
        auto& engine = fa::gameEngine();

        if (down) {
            const auto r = engine.onRealPress(t, isPlayer1);
            if (r.preRelease) fa::injectButton(this, false, r.preReleaseIsPlayer1);
            if (r.forward) GJBaseGameLayer::handleButton(true, button, isPlayer1);
        } else {
            const auto r = engine.onRealRelease(t, isPlayer1);
            if (r.forward) GJBaseGameLayer::handleButton(false, button, isPlayer1);
        }
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        if (fa::isPlayLayer(this)) {
            auto& engine = fa::gameEngine();
            if (engine.active()) {
                const bool isP1 = engine.isPlayer1();
                if (PlayerObject* player = isP1 ? m_player1 : m_player2) {
                    const fa::PlayerView view{flyModeOf(player), static_cast<double>(player->getPositionY()),
                                              player->m_isUpsideDown ? -1.0 : 1.0};
                    const auto tick = static_cast<std::uint32_t>(m_gameState.m_currentProgress);
                    const int action = g_drive.step(engine, fa::straightConfig(), tick, view);
                    if (action != 0) fa::injectButton(this, action > 0, isP1);
                }
            } else {
                g_drive.idle();                       // not assisting: the next activation starts clean
            }
        }
        GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick);
    }

    void update(float dt) {
        if (fa::isPlayLayer(this)) {
            const double t = fa::now();
            fa::refreshConfig(t);
            auto& engine = fa::gameEngine();
            const auto out = engine.tick(t);
            if (out.action != fa::Action::None) {
                fa::injectButton(this, out.action == fa::Action::Press, out.isPlayer1);
            }
            fa::noteCoopBackoff(engine);
        }
        GJBaseGameLayer::update(dt);
    }
};

class $modify(FlowPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        fa::refreshConfig(fa::now(), true);
        fa::gameEngine().reset(/*newLevel=*/true);
        fa::gameEngine().setExternalDrive(true);   // in the game the clicks come from the tick drive above
        g_drive.reset();

        const auto& cfg = fa::gameEngine().config();
        if (cfg.yielding) log::info("Flow Assist: Afterflow is loaded - yielding, input is left untouched");
        else if (cfg.coop) log::info("Flow Assist: Afterflow is loaded - sharing input (co-op mode)");

        CCNode* parent = UILayer::get();
        if (!parent) parent = this;
        fa::attachHud(parent);
    }

    void resetLevel() {
        PlayLayer::resetLevel();
        g_drive.reset();
        const auto r = fa::gameEngine().reset();
        if (r.action == fa::Action::Release) fa::injectButton(this, false, r.isPlayer1);
    }

    void onQuit() {
        fa::gameEngine().reset(/*newLevel=*/true);
        g_drive.reset();
        PlayLayer::onQuit();
    }
};
