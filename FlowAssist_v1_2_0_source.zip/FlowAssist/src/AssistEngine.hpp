#pragma once

// Flow Assist - core rhythm engine.
//
// Pure C++20. It knows nothing about Geometry Dash or Geode, which is what makes it
// unit-testable on any machine (see tests/). The Geode layer feeds it the player's real
// button events plus one tick() per frame, and does whatever it says.
//
// Behaviour in one paragraph:
//   * Every real press of the jump button is time-stamped and the player's CPS is measured
//     over the current click burst (computed once per press, then cached).
//   * While the assist is NOT active (feature off, yielding to Afterflow, or CPS below the
//     activation threshold) every real event is forwarded untouched: vanilla behaviour, no added
//     latency.
//   * When CPS reaches the activation threshold the assist switches on. It adopts the press
//     that tipped it over as its first click and from then on drives the button itself at
//       drive = pace + strength * (target - pace)          (pace = the player's smoothed CPS)
//     clicks per second, evenly spaced. The player's own presses/releases are swallowed
//     while it is active; they only keep the assist alive and update `pace`.
//   * Output is frame-aware: every press goes out on the frame nearest to its ideal time and
//     every release a whole number of frames later, so the rhythm and the press length stay
//     constant instead of wobbling with the frame-time noise.
//   * Two-finger alternation (presses that overlap) is recognised and is not mistaken for a hold.
//   * It switches off (and resyncs the game's button state to the player's finger) when the
//     player stops clicking, slows well below the threshold, holds the button down, switches
//     to the other player's side, or the feature is disabled / yielding.
//   * In the game the button is driven on the 240 Hz physics-tick grid by the game layer (TickDrive.hpp):
//     setExternalDrive(true) makes tick() keep all of its checks but emit no press/release of its own, and the
//     layer reports what it sent through noteDriven(). Without it (settings-page tap pad, unit tests) the engine
//     produces its own frame-aware rhythm, as in v1.1.0.
//   * Events it did not expect (a release with no finger down) are never swallowed: they may be
//     input that another mod held back and re-sent. With `coop` set the assist also backs off.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace fa {

struct Config {
    bool   enabled       = true;
    double activationCps = 8.0;   // assist engages once the player clicks at least this fast
    double targetCps     = 12.0;  // rate the assist drives towards
    double strength      = 0.6;   // 0..1  (0 = replay the player's own pace evenly, 1 = lock to targetCps)
    double holdBreak     = 0.11;  // seconds a finger must stay down before the assist hands the button back
    bool   yielding      = false; // Afterflow is loaded and the user chose "Yield": behave exactly like disabled
    bool   coop          = false; // Afterflow is loaded and the user chose "Share": back off on foreign input
};

enum class Action : std::uint8_t { None, Press, Release };

struct PressResult {
    bool forward = true;              // pass the real press on to the game
    bool preRelease = false;          // send a synthetic release BEFORE forwarding (assist was holding the button)
    bool preReleaseIsPlayer1 = true;  // which side that synthetic release belongs to
    bool activated = false;           // the assist switched on with this press
};

struct ReleaseResult {
    bool forward = true;              // pass the real release on to the game
};

struct TickResult {
    Action action = Action::None;     // synthetic event to send to the game right now
    bool isPlayer1 = true;            // side to send it on
    bool deactivated = false;         // the assist switched off on this tick
};

struct ResetResult {
    Action action = Action::None;     // synthetic release to send, if the assist was holding the button
    bool isPlayer1 = true;
};

struct Snapshot {
    double cps = 0.0;                 // player's current CPS
    double driveCps = 0.0;            // rate the assist is currently producing (0 when inactive)
    bool enabled = false;
    bool yielding = false;            // enabled, but deliberately staying out of the way (Afterflow)
    bool active = false;
    bool lockedOut = false;           // co-op back-off: assist paused for the rest of this level
    bool straight = false;            // active and the game layer is flying the player level (Go Straight)
    std::uint32_t assisted = 0;       // total synthetic presses sent so far (monotonic)
    std::uint32_t foreign = 0;        // unexpected events seen while the assist was active
};

class Engine {
public:
    static constexpr double kWindow     = 1.0;   // CPS look-back, seconds
    static constexpr double kBurstGap   = 0.6;   // a longer pause ends a click burst, seconds
    static constexpr int    kMinClicks  = 4;     // presses in the burst required before the assist may start
    static constexpr double kHysteresis = 0.75;  // stays active until CPS < activation * this
    static constexpr double kMaxCps     = 60.0;  // hard cap for any rate we report or produce
    static constexpr double kAltMemory  = 0.6;   // overlapping presses seen this recently = two-finger alternation
    static constexpr double kCoopCooldown = 2.0; // co-op back-off: no activation for this long after a foreign event
    static constexpr std::uint32_t kCoopMaxForeign = 3;  // ...and none for the rest of the level after this many

    void setConfig(Config const& c) {
        cfg_.enabled       = c.enabled;
        cfg_.activationCps = clampd(c.activationCps, 1.0, kMaxCps);
        cfg_.targetCps     = clampd(c.targetCps, 1.0, kMaxCps);
        cfg_.strength      = clampd(c.strength, 0.0, 1.0);
        cfg_.holdBreak     = clampd(c.holdBreak, 0.04, 0.5);
        cfg_.yielding      = c.yielding;
        cfg_.coop          = c.coop;
    }
    Config const& config() const { return cfg_; }

    // ---- real input -------------------------------------------------------------------

    PressResult onRealPress(double now, bool isPlayer1) {
        PressResult out;
        lastSeen_ = now;
        const int s = sideIdx(isPlayer1);

        if (!active_ && count_ > 0 && histSide_ != isPlayer1) clearHistory();  // other side: start a fresh burst
        pushPress(now);
        histSide_ = isPlayer1;

        if (phys_[s] == 0) holdStart_[s] = now;
        else if (now - lastRealPress_ < kBurstGap) lastOverlapAt_ = now;      // a second finger while one is down
        // Co-op mode cannot count fingers: a re-sent copy of an event would be counted as a finger and leave a
        // phantom behind. There the state is just "down since the last press / up since the last release".
        phys_[s] = cfg_.coop ? 1 : phys_[s] + 1;
        lastRealPress_ = now;

        if (active_) {
            if (effEnabled() && isPlayer1 == side_) {
                updatePace();
                out.forward = false;              // the assist owns the button while it is active
                return out;
            }
            // Feature switched off, or the other player's side was pressed: hand control back.
            out.preRelease = assistHolding_;
            out.preReleaseIsPlayer1 = side_;
            active_ = false;
            assistHolding_ = false;
            clearHistory();
            pushPress(now);
            side_ = isPlayer1;
            gameDown_ = true;
            return out;                           // forward stays true
        }

        side_ = isPlayer1;
        gameDown_ = true;
        if (effEnabled() && shouldActivate(now)) {
            beginActive(now);
            out.activated = true;                 // this press is forwarded and becomes the assist's first click
        }
        return out;
    }

    ReleaseResult onRealRelease(double now, bool isPlayer1 = true) {
        ReleaseResult out;
        lastSeen_ = now;
        const int s = sideIdx(isPlayer1);

        if (phys_[s] == 0) {
            // No finger is down on that side, so this release cannot be the player's: something re-sent it
            // (for example a mod that holds input back and delivers it later). Never swallow it.
            if (active_) noteForeign(now);
            return out;                           // forward stays true
        }
        phys_[s] = cfg_.coop ? 0 : phys_[s] - 1;

        if (active_ && isPlayer1 == side_) {
            out.forward = false;                  // the assist decides when the game sees a release
            return out;
        }
        if (!active_ && isPlayer1 == side_) gameDown_ = false;
        return out;                               // the other player's release is never ours to swallow
    }

    // ---- per-frame ----------------------------------------------------------------------

    TickResult tick(double now) {
        TickResult out;
        out.isPlayer1 = side_;
        lastSeen_ = now;

        if (pending_ != Action::None) {           // hand-back left over from a co-op back-off
            out.action = pending_;
            if (pending_ == Action::Press) gameDown_ = true;
            pending_ = Action::None;
            prevTickAt_ = lastTickAt_;
            lastTickAt_ = now;
            return out;
        }
        if (!active_) {                           // cheap path: nothing to do while inactive
            prevTickAt_ = lastTickAt_;            // (just remember when frames happened, see seedFrameInterval())
            lastTickAt_ = now;
            return out;
        }
        trackFrame(now);

        const int s = sideIdx(side_);
        const bool finger = phys_[s] > 0;
        const bool alt = finger && alternating(now);   // two fingers taking turns: the finger is never "up"
        const double period = 1.0 / std::max(pace_, 1.0);
        const double idleTimeout = clampd(1.8 * period, 0.15, 0.40);
        const double downFor = alt ? now - lastRealPress_ : now - holdStart_[s];
        const double holdLimit = alt ? std::max(cfg_.holdBreak, 1.6 * period) : cfg_.holdBreak;

        const bool idle = !finger && (now - lastRealPress_) > idleTimeout;   // player stopped clicking
        const bool held = finger && downFor > holdLimit;                     // player is holding, not spamming
        const bool slow = stats_.rate < cfg_.activationCps * kHysteresis;    // fell below the configured conditions
        if (!effEnabled() || idle || held || slow) {
            out.action = leaveActive(finger);
            out.deactivated = true;
            return out;
        }

        if (ext_) return out;                     // the game layer produces the clicks, on the tick grid

        if (assistHolding_) {
            // Release on schedule, so the press length stays constant. The one exception: a finger that has
            // been down for half the hold-break time may be a real hold, so keep the button down and let the
            // held-detection above hand it over without a gap. Ordinary spam taps are shorter than this.
            const bool looksLikeHold = finger && !alt && (now - holdStart_[s]) >= 0.5 * cfg_.holdBreak;
            if (now >= releaseAt_ && !looksLikeHold) {
                assistHolding_ = false;
                gameDown_ = false;
                out.action = Action::Release;
            }
            return out;
        }

        if (now + 0.5 * frameDt_ >= nextTick_) {  // nearest frame to the ideal press time
            const double period2 = 1.0 / driveCps();
            nextTick_ += period2;
            if (nextTick_ < now) nextTick_ = now + period2;  // fell behind (frame hitch): skip the backlog, never burst
            assistHolding_ = true;
            gameDown_ = true;
            ++assisted_;
            releaseAt_ = now + holdSpan(period2);
            out.action = Action::Press;
        }
        return out;
    }

    // Level (re)start / quit: forget everything. Returns a release if the assist was holding the button.
    // `newLevel` additionally clears the co-op back-off so the next level starts fresh.
    ResetResult reset(bool newLevel = false) {
        ResetResult r;
        r.isPlayer1 = side_;
        if (active_ && assistHolding_) r.action = Action::Release;
        active_ = false;
        assistHolding_ = false;
        gameDown_ = false;
        pending_ = Action::None;
        phys_ = {0, 0};
        holdStart_ = {-1e9, -1e9};
        pace_ = 0.0;
        lastRealPress_ = -1e9;
        lastOverlapAt_ = -1e9;
        nextTick_ = 0.0;
        releaseAt_ = 0.0;
        coolUntil_ = 0.0;
        holdFrames_ = 0.0;
        straightShown_ = false;
        if (newLevel) {
            lockedOut_ = false;
            foreign_ = 0;
        }
        clearHistory();
        return r;
    }

    // ---- tick-grid drive (used by the game layer, see TickDrive.hpp) ------------------------

    // On: tick() never emits a press/release of its own. Set once for the engine that runs the real game.
    void setExternalDrive(bool on) { ext_ = on; }
    bool externalDrive() const { return ext_; }
    // The game layer sent a press (true) / release (false) on the engine's behalf: keeps the hand-back state exact.
    void noteDriven(bool down) {
        if (!active_) return;
        assistHolding_ = down;
        gameDown_ = down;
        if (down) ++assisted_;
    }
    // For the readouts: the layer is flying the player level (Go Straight) rather than clicking a plain rhythm.
    void setStraightShown(bool on) { straightShown_ = on; }
    // The plain-rhythm rate (clicks per second) the layer should use when it is not flying straight.
    double rhythmCps() const { return driveCps(); }

    // ---- readouts -----------------------------------------------------------------------

    // Player's current CPS: presses per second over the current click burst, decaying to 0
    // once the player stops. A "burst" is the run of presses that are < kBurstGap apart and
    // fall inside the last kWindow seconds.
    double cps(double now) const {
        const double r = stats_.rate;
        if (r <= 0.0) return 0.0;
        const double since = now - lastPressTime();
        if (since > kWindow) return 0.0;
        return since > 0.0 ? std::min(r, 1.0 / since) : r;
    }

    Snapshot snapshot(double now) const {
        Snapshot s;
        s.cps = cps(now);
        s.enabled = cfg_.enabled;
        s.yielding = cfg_.enabled && cfg_.yielding;
        s.active = active_ && (now - lastSeen_) < 0.5;   // stale if nobody has ticked us lately
        s.lockedOut = lockedOut_;
        s.driveCps = s.active ? driveCps() : 0.0;
        s.straight = s.active && ext_ && straightShown_;
        s.assisted = assisted_;
        s.foreign = foreign_;
        return s;
    }

    bool active() const { return active_; }
    bool isPlayer1() const { return side_; }
    bool gameButtonDown() const { return gameDown_; }
    bool fingerDown() const { return phys_[0] + phys_[1] > 0; }
    bool lockedOut() const { return lockedOut_; }
    std::uint32_t assisted() const { return assisted_; }
    std::uint32_t foreign() const { return foreign_; }
    double frameInterval() const { return frameDt_; }

private:
    struct Stats {
        int m = 0;              // presses in the current burst
        double first = 0.0;
        double last = 0.0;
        double lastGap = 1e9;   // interval between the two newest presses
        double rate = 0.0;      // presses per second over the burst (0 = unknown)
    };

    static double clampd(double v, double lo, double hi) {
        if (!std::isfinite(v)) return lo;
        return v < lo ? lo : (v > hi ? hi : v);
    }
    static int sideIdx(bool isPlayer1) { return isPlayer1 ? 0 : 1; }

    bool effEnabled() const { return cfg_.enabled && !cfg_.yielding; }
    bool alternating(double now) const { return (now - lastOverlapAt_) < kAltMemory; }

    static constexpr int kCap = 64;

    void pushPress(double t) {
        times_[head_] = t;
        head_ = (head_ + 1) % kCap;
        if (count_ < kCap) ++count_;
        refreshStats();
    }
    double newest(int k) const { return times_[(head_ - 1 - k + 2 * kCap) % kCap]; }   // k = 0 is the newest
    double lastPressTime() const { return count_ > 0 ? newest(0) : -1e9; }
    void clearHistory() {
        head_ = 0;
        count_ = 0;
        refreshStats();
    }

    // The burst only changes when a press is added or the history is cleared, so its statistics are
    // computed once there and every per-frame check reads the cached values.
    void refreshStats() {
        Stats s;
        if (count_ > 0) {
            s.m = 1;
            s.last = s.first = newest(0);
            double prev = s.last;
            for (int k = 1; k < count_; ++k) {
                const double t = newest(k);
                const double gap = prev - t;
                if (gap > kBurstGap || s.last - t > kWindow) break;
                if (s.m == 1) s.lastGap = gap;
                ++s.m;
                s.first = t;
                prev = t;
            }
            s.rate = fitRate(s.m, s.last - s.first);
        }
        stats_ = s;
    }

    // Presses per second over the burst: (m-1) intervals in `span` seconds. A least-squares slope was tried
    // and measured worse than this once real click-to-click jitter is present (tests/compare_test.cpp [A]),
    // so the plain end-point rate stays.
    static double fitRate(int m, double span) {
        if (m < 2) return 0.0;
        if (span < 1e-4) return 0.0;
        return std::min(static_cast<double>(m - 1) / span, m >= 3 ? kMaxCps : 12.0);
    }

    bool shouldActivate(double now) const {
        if (stats_.m < kMinClicks) return false;
        if (stats_.rate < cfg_.activationCps) return false;
        if (stats_.lastGap > 1.8 / cfg_.activationCps) return false;   // a lone click after a pause must not trigger it
        if (cfg_.coop && (lockedOut_ || now < coolUntil_)) return false;
        return true;
    }

    void updatePace() {
        if (stats_.rate > 0.0) pace_ += 0.3 * (stats_.rate - pace_);
    }

    double driveCps() const {
        const double p = std::max(pace_, 1.0);
        return clampd(p + cfg_.strength * (cfg_.targetCps - p), 2.0, kMaxCps);
    }

    // How long the assist keeps its press down, as an offset from the press frame. The target is 40 % of
    // the period (12..45 ms); it is turned into a whole number of frames and the release is armed half a
    // frame early, so it lands exactly that many frames after the press whatever the frame-time noise. The
    // frame count is sticky: it only changes when the target moves by more than 3/4 of a frame, so a target
    // sitting on a rounding boundary cannot flip between two lengths from click to click.
    double holdSpan(double period) {
        const double fd = frameDt_;
        const double want = clampd(0.4 * period, 0.012, 0.045) / fd;
        double frames = holdFrames_;
        if (frames < 1.0 || std::fabs(want - frames) > 0.75) frames = std::floor(want + 0.5);
        const double maxFrames = std::max(1.0, std::floor(period / fd) - 1.0);   // keep one frame of "up" per click
        frames = std::min(std::max(frames, 1.0), maxFrames);
        holdFrames_ = frames;
        return (frames - 0.5) * fd;
    }

    // Frame interval. While the assist is inactive nothing is smoothed (that is almost all of the game);
    // when it activates the interval is seeded from the last two frames, and from then on every tick
    // refines it. A hitch (or a pause) is clamped to 0.5x..2x of the estimate, or ignored when absurd.
    void seedFrameInterval() {
        const double dt = lastTickAt_ - prevTickAt_;
        if (prevTickAt_ > -1e8 && dt > 1e-4 && dt < 0.25) frameDt_ = dt;
    }
    void trackFrame(double now) {
        const double dt = now - lastTickAt_;
        prevTickAt_ = lastTickAt_;
        lastTickAt_ = now;
        if (!(dt > 1e-4 && dt < 0.25)) return;     // also false for NaN
        const double lo = 0.5 * frameDt_;
        const double hi = 2.0 * frameDt_;
        frameDt_ += 0.1 * ((dt < lo ? lo : (dt > hi ? hi : dt)) - frameDt_);
    }

    void beginActive(double now) {
        seedFrameInterval();
        active_ = true;
        assistHolding_ = true;       // the press that tipped us over is adopted as the first click
        gameDown_ = true;
        pace_ = stats_.rate;
        const double period = 1.0 / driveCps();
        releaseAt_ = now + holdSpan(period);
        nextTick_ = now + period;
    }

    // Leaves assist mode and returns whatever the game needs to see so that its button state
    // matches the player's finger from here on.
    Action leaveActive(bool fingerDown) {
        Action a = Action::None;
        if (cfg_.coop && foreign_ > 0) {
            // Input is being re-sent behind our back (Afterflow), so the finger state cannot be trusted any more:
            // a re-sent press can look like a finger that is not there. Fail "up": always end with a release, and
            // never press on the player's behalf. (A spare release is harmless.)
            a = Action::Release;
            fingerDown = false;
        } else if (assistHolding_) {
            if (!fingerDown) a = Action::Release;   // finger down: the held button now simply belongs to the player
        } else if (fingerDown) {
            a = Action::Press;                      // player is holding but the game saw the assist's release
        }
        active_ = false;
        assistHolding_ = false;
        gameDown_ = fingerDown;
        clearHistory();
        return a;
    }

    // A release nobody expected arrived while the assist was running. In co-op mode (Afterflow loaded and
    // "Share" chosen) that is taken as proof that input is being re-sent behind our back: stop owning the
    // button, and stay out of the way for a while / for the rest of the level.
    void noteForeign(double now) {
        ++foreign_;
        if (!cfg_.coop || !effEnabled()) return;
        coolUntil_ = now + kCoopCooldown;
        if (foreign_ >= kCoopMaxForeign) lockedOut_ = true;
        // The release we are about to forward reaches the game: its button is up whatever we thought.
        assistHolding_ = false;
        gameDown_ = false;
        const Action a = leaveActive(phys_[sideIdx(side_)] > 0);
        if (a != Action::None) pending_ = a;
    }

    Config cfg_{};

    std::array<double, kCap> times_{};
    int head_ = 0;
    int count_ = 0;
    bool histSide_ = true;
    Stats stats_{};

    bool active_ = false;
    bool assistHolding_ = false;   // an assist-made press is currently down in the game
    bool gameDown_ = false;        // what the game believes the button state is
    bool side_ = true;             // isPlayer1 of the clicks being assisted
    Action pending_ = Action::None;

    std::array<int, 2> phys_{0, 0};                      // fingers / keys physically down, per player side
    std::array<double, 2> holdStart_{-1e9, -1e9};        // when the first finger of each side went down
    double lastRealPress_ = -1e9;
    double lastOverlapAt_ = -1e9;  // last press that arrived while another finger was already down
    double lastSeen_ = -1e9;

    double pace_ = 0.0;            // smoothed player CPS while active
    double nextTick_ = 0.0;
    double releaseAt_ = 0.0;
    std::uint32_t assisted_ = 0;

    double frameDt_ = 1.0 / 60.0;  // smoothed time between ticks (= frames)
    double holdFrames_ = 0.0;      // current press length in frames (see holdSpan)
    double lastTickAt_ = -1e9;     // the two most recent tick() times
    double prevTickAt_ = -1e9;

    bool ext_ = false;             // the game layer drives the button on the tick grid
    bool straightShown_ = false;   // readout only

    double coolUntil_ = 0.0;       // co-op back-off
    std::uint32_t foreign_ = 0;
    bool lockedOut_ = false;
};

}  // namespace fa
