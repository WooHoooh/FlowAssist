#pragma once

// Default values for every Flow Assist setting.
//
// These MUST match the "default" fields in mod.json. The "Reset to Defaults" button writes
// these values, and tools/check_defaults.py (run in CI) fails if the two ever drift apart.

#include <cstdint>

namespace fa::defaults {

inline constexpr bool         enabled       = true;
inline constexpr double       activationCps = 8.0;
inline constexpr double       targetCps     = 12.0;
inline constexpr std::int64_t strength      = 60;      // percent
inline constexpr std::int64_t holdBreakMs   = 110;
inline constexpr bool         goStraight    = true;
inline constexpr const char*  straightLaw   = "Predictive";   // "Predictive" or "Classic"
inline constexpr std::int64_t cpsShip       = 20;
inline constexpr std::int64_t cpsWave       = 15;
inline constexpr std::int64_t cpsUfo        = 12;
inline constexpr std::int64_t cpsSwing      = 12;
inline constexpr bool         showHud       = true;
inline constexpr const char*  hudPosition   = "Top Left";
inline constexpr const char*  afterflowMode = "Yield";   // what to do when Afterflow is loaded: "Yield" or "Share"

}  // namespace fa::defaults
