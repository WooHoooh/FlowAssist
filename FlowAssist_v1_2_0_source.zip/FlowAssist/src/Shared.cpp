#include "Shared.hpp"

#include <algorithm>
#include <chrono>
#include <string>

#include "Defaults.hpp"

using namespace geode::prelude;

namespace fa {

bool g_injecting = false;

namespace {

struct InjectGuard {
    InjectGuard() { g_injecting = true; }
    ~InjectGuard() { g_injecting = false; }
    InjectGuard(InjectGuard const&) = delete;
    InjectGuard& operator=(InjectGuard const&) = delete;
};

}  // namespace

double now() {
    using clock = std::chrono::steady_clock;
    return std::chrono::duration<double>(clock::now().time_since_epoch()).count();
}

Engine& gameEngine() {
    static Engine engine;
    return engine;
}

Engine& padEngine() {
    static Engine engine;
    return engine;
}

double& padLastTap() {
    static double t = -1e9;
    return t;
}

bool afterflowLoaded() {
    // isModLoaded() is true only for mods that are installed AND enabled, so disabling Afterflow in Geode's
    // mod list immediately gives Flow Assist its full behaviour back.
    return Loader::get()->isModLoaded("afterflow.prsevend");
}

namespace {

StraightConfig& straightStore() {
    static StraightConfig cfg;
    return cfg;
}

StraightConfig readStraightConfig() {
    auto* mod = Mod::get();
    StraightConfig c;
    c.enabled = mod->getSettingValue<bool>("go-straight");
    c.law = mod->getSettingValue<std::string>("straight-law") == "Classic" ? StraightLaw::Classic : StraightLaw::Predictive;
    c.cps[0] = static_cast<double>(mod->getSettingValue<int64_t>("cps-ship"));
    c.cps[1] = static_cast<double>(mod->getSettingValue<int64_t>("cps-wave"));
    c.cps[2] = static_cast<double>(mod->getSettingValue<int64_t>("cps-ufo"));
    c.cps[3] = static_cast<double>(mod->getSettingValue<int64_t>("cps-swing"));
    for (auto& v : c.cps) v = std::clamp(v, 2.0, 60.0);
    return c;
}

}  // namespace

StraightConfig const& straightConfig() { return straightStore(); }

Config readConfig() {
    auto* mod = Mod::get();
    Config c;
    c.enabled       = mod->getSettingValue<bool>("enabled");
    c.activationCps = mod->getSettingValue<double>("activation-cps");
    c.targetCps     = mod->getSettingValue<double>("target-cps");
    c.strength      = static_cast<double>(mod->getSettingValue<int64_t>("strength")) / 100.0;
    c.holdBreak     = static_cast<double>(mod->getSettingValue<int64_t>("hold-break-ms")) / 1000.0;
    if (afterflowLoaded()) {
        const bool share = mod->getSettingValue<std::string>("afterflow-mode") == "Share";
        c.yielding = !share;   // Yield (default): behave exactly as if Flow Assist were not installed
        c.coop     = share;    // Share: keep working, back off if input is being re-sent behind our back
    }
    return c;
}

void refreshConfig(double t, bool force) {
    static double last = -1e9;
    if (!force && t - last < 0.1) return;
    last = t;
    const Config c = readConfig();
    straightStore() = readStraightConfig();
    gameEngine().setConfig(c);
    Config pad = c;            // the settings-page tap pad never touches the game, so Afterflow is irrelevant to it
    pad.yielding = false;
    pad.coop = false;
    padEngine().setConfig(pad);
}

void noteCoopBackoff(Engine const& engine) {
    static bool announced = false;
    if (!engine.lockedOut()) {
        announced = false;
        return;
    }
    if (announced) return;
    announced = true;
    log::warn("Flow Assist: input is being re-sent by another mod (Afterflow); assist paused for the rest of this level");
}

void resetSettingsToDefaults() {
    auto* mod = Mod::get();
    (void)mod->setSettingValue<bool>("enabled", defaults::enabled);
    (void)mod->setSettingValue<double>("activation-cps", defaults::activationCps);
    (void)mod->setSettingValue<double>("target-cps", defaults::targetCps);
    (void)mod->setSettingValue<int64_t>("strength", defaults::strength);
    (void)mod->setSettingValue<int64_t>("hold-break-ms", defaults::holdBreakMs);
    (void)mod->setSettingValue<bool>("go-straight", defaults::goStraight);
    (void)mod->setSettingValue<std::string>("straight-law", std::string(defaults::straightLaw));
    (void)mod->setSettingValue<int64_t>("cps-ship", defaults::cpsShip);
    (void)mod->setSettingValue<int64_t>("cps-wave", defaults::cpsWave);
    (void)mod->setSettingValue<int64_t>("cps-ufo", defaults::cpsUfo);
    (void)mod->setSettingValue<int64_t>("cps-swing", defaults::cpsSwing);
    (void)mod->setSettingValue<bool>("show-hud", defaults::showHud);
    (void)mod->setSettingValue<std::string>("hud-position", std::string(defaults::hudPosition));
    (void)mod->setSettingValue<std::string>("afterflow-mode", std::string(defaults::afterflowMode));
    refreshConfig(now(), true);
}

bool isPlayLayer(GJBaseGameLayer* layer) {
    auto* play = PlayLayer::get();
    return play != nullptr && static_cast<GJBaseGameLayer*>(play) == layer;
}

void injectButton(GJBaseGameLayer* layer, bool down, bool isPlayer1) {
    if (!layer) return;
    InjectGuard guard;
    const auto queued = layer->m_queuedButtons.size();
    layer->handleButton(down, 1, isPlayer1);
    // GD's queued input modes stamp inputs with wall-clock time; pin ours to the tick being processed
    if (layer->m_queuedButtons.size() > queued) layer->m_queuedButtons.back().m_timestamp = layer->m_timestamp;
}

}  // namespace fa
