#pragma once

// Flow Assist - tick-grid drive.
//
// Pure C++20, no Geometry Dash / Geode types (unit-tested in tests/straight_test.cpp).
//
// The rhythm engine in AssistEngine.hpp decides WHEN the assist is on. This file decides WHAT the button does
// while it is on, once per physics tick (GD 2.2 runs 240 ticks per second, independent of the frame rate):
//
//   * TickRhythm  - steady press/release on the tick grid (cube, ball, robot, spider, or Go Straight off).
//   * Leveler     - "Go Straight" for ship, wave, UFO and swing: keeps the player at the height it was at when
//                   the assist took over, while never clicking faster than the CPS limit of that gamemode.
//
// Leveler has two laws:
//   Classic    - the original Alternate Assist / Voidius law: switch on a fixed look-ahead of the position.
//   Predictive - learns how hard the button accelerates the player (units per tick^2, measured from the
//                position it observes every tick) and switches where the player would come to rest. It needs no
//                gamemode constants, so it follows speed portals, mini, size and gravity changes by itself.
//                Until it has measured enough it falls back to the Classic law, and it falls back again if its
//                measurements stop making sense.

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>

namespace fa {

inline constexpr double kTps = 240.0;   // physics ticks per second at normal game speed

enum class Fly : std::uint8_t { None, Ship, Wave, Ufo, Swing };

inline constexpr bool isFlying(Fly f) { return f != Fly::None; }

enum class StraightLaw : std::uint8_t { Classic, Predictive };

struct StraightConfig {
    bool        enabled = true;                         // "Go Straight"
    StraightLaw law = StraightLaw::Predictive;
    std::array<double, 4> cps{20.0, 15.0, 12.0, 12.0};  // fastest click rate: ship, wave, UFO, swing

    double cpsFor(Fly f) const {
        switch (f) {
            case Fly::Ship: return cps[0];
            case Fly::Wave: return cps[1];
            case Fly::Ufo: return cps[2];
            case Fly::Swing: return cps[3];
            default: return 0.0;
        }
    }
};

// Steady rhythm on the tick grid. `period` is in ticks (240 / cps). Each press is held for `holdFraction` of the
// period, never less than one tick down and never less than one tick up, so every click registers.
class TickRhythm {
public:
    // The press that switched the assist on counts as the first click (`held`). Starting with the button up
    // (a gamemode change in the middle of the assist) presses on the very next step.
    void begin(std::uint32_t tick, double period, double holdFraction, bool held = true) {
        held_ = held;
        releaseAt_ = tick + holdTicks(period, holdFraction);
        nextPress_ = static_cast<double>(tick) + (held ? period : 0.0);
    }

    // +1 press, -1 release, 0 nothing, for this tick.
    int step(std::uint32_t tick, double period, double holdFraction) {
        if (held_ && tick >= releaseAt_) {
            held_ = false;
            return -1;
        }
        if (!held_ && static_cast<double>(tick) >= nextPress_) {
            held_ = true;
            releaseAt_ = tick + holdTicks(period, holdFraction);
            nextPress_ += period;
            if (nextPress_ <= static_cast<double>(tick)) nextPress_ = static_cast<double>(tick) + period;  // lag: never burst
            return 1;
        }
        return 0;
    }

    bool held() const { return held_; }

private:
    static std::uint32_t holdTicks(double period, double fraction) {
        const int whole = std::max(2, static_cast<int>(period));
        return static_cast<std::uint32_t>(std::clamp(static_cast<int>(std::lround(period * fraction)), 1, whole - 1));
    }

    double nextPress_ = 0.0;
    std::uint32_t releaseAt_ = 0;
    bool held_ = false;
};

// Level-flight controller. Feed it the player's height once per tick through the step*() call for the gamemode;
// it answers +1 (press), -1 (release) or 0 (leave the button as it is) and does its own bookkeeping for that answer.
// All heights are in game units, all speeds in units per tick.
class Leveler {
public:
    // The first click already happened (it is the press that started the assist), at the current height.
    void start(double y, bool held) {
        *this = Leveler(law_);
        target_ = lastY_ = y;
        haveY_ = true;
        held_ = held;
        since_ = 0;
        tapPending_ = false;      // the adopted press has not moved the player yet when we first look at it
        flipPending_ = held;
    }

    Leveler() = default;
    explicit Leveler(StraightLaw law) : law_(law) {}

    void setLaw(StraightLaw l) { law_ = l; }
    StraightLaw law() const { return law_; }
    double target() const { return target_; }
    bool held() const { return held_; }

    // True once the predictive law has enough measurements for this gamemode.
    bool learned(Fly mode) const {
        switch (mode) {
            case Fly::Ship: return nUp_ >= kNeed && nDown_ >= kNeed && ratioOk(accUp_, accDown_);
            case Fly::Ufo: return nGrav_ >= kNeed && nTap_ >= 1 && grav_ > kMinSample;
            case Fly::Swing: return nSwing_ >= kNeed && accSign_ != 0;
            default: return false;
        }
    }

    // Ship: hold while below the target. `up` is +1 when holding moves the player up on screen, -1 when flipped.
    int stepShip(double y, double up, int minTicks) {
        const double v = observe(y, up, Fly::Ship);
        bool want;
        if (predictive() && learned(Fly::Ship)) {
            const double a = held_ ? accUp_ : -accDown_;                 // acceleration in force until we may switch
            const double lead = std::max(0, minTicks - since_) + kLeadShip * minTicks;
            const double e = (y - target_) * up + v * up * lead + 0.5 * a * lead * lead;
            const double vn = v * up + a * lead;
            want = e + restOffset(vn, accUp_, accDown_) < 0.0;
        } else {
            want = (target_ - (y + v * 10.0)) * up > 0.0;                // Classic: fixed look-ahead
        }
        return switchTo(want, minTicks);
    }

    // Wave: no inertia (its vertical speed is +/- its horizontal speed), so the position alone decides, and the
    // straightness is set by how short a leg the CPS limit allows.
    int stepWave(double y, double up, int minTicks) {
        const double v = observe(y, up, Fly::Wave);
        return switchTo((target_ - (y + v)) * up > 0.0, minTicks);
    }

    // UFO: a one-tick tap makes it jump. Predictive: tap when the jump arc that tap starts would be centred on the
    // target (or lower), at most one tap per `minGap` ticks.
    int stepUfo(double y, double up, int minGap) {
        const double v = observe(y, up, Fly::Ufo);
        if (held_) return since_ >= 1 ? release() : 0;
        if (since_ < minGap) return 0;
        bool want;
        if (predictive() && learned(Fly::Ufo)) {
            // A tap always gives the same jump (speed tapV_), so the arc is the same every time: its height is
            // H = tapV^2 / 2g. Starting it H/2 below the target puts the arc symmetrically around the target,
            // which is the smallest possible distance from the target for this gamemode.
            const double half = tapV_ * tapV_ / (4.0 * grav_);
            want = (y + v - target_) * up + half <= 0.0;
        } else {
            want = (target_ - (y + v * 12.0)) * up > 0.0;                // Classic
        }
        return want ? press() : 0;
    }

    // Swing: a tap flips gravity. Predictive: flip so that the player comes to rest at the target; it only flips
    // once it has measured which way gravity currently pulls. Classic: flip whenever it moves away from the target.
    int stepSwing(double y, int minGap) {
        const double v = observe(y, 1.0, Fly::Swing);
        if (held_) return since_ >= 1 ? release() : 0;
        if (since_ < minGap) return 0;
        bool want;
        if (predictive()) {
            if (!learned(Fly::Swing)) return 0;
            const double a = accSign_ * gSwing_;
            const double lead = kLeadSwing * minGap;
            const double e = (y - target_) + v * lead + 0.5 * a * lead * lead;
            const double vv = v + a * lead;
            const bool wantUp = e + restOffset(vv, gSwing_, gSwing_) < 0.0;
            want = wantUp != (accSign_ > 0);
        } else {
            want = (y < target_ - 2.0 && v < 0.0) || (y > target_ + 2.0 && v > 0.0);
        }
        return want ? press() : 0;
    }

private:
    static constexpr int    kNeed = 3;           // measurements needed before the predictive law is trusted
    static constexpr double kTeleport = 40.0;    // a bigger jump in one tick is a portal / teleport
    static constexpr double kMinSample = 1e-3;   // smaller accelerations are clamps and noise, not measurements
    static constexpr double kLeadShip = 0.25;     // predictive look-ahead beyond the lock-out, in dwell lengths
    static constexpr double kLeadSwing = 0.5;

    bool predictive() const { return law_ == StraightLaw::Predictive; }
    static bool ratioOk(double a, double b) { return a > kMinSample && b > kMinSample && a < 6.0 * b && b < 6.0 * a; }

    // Where a player moving at `vn` (up-positive) comes to rest, relative to where it is now, if the control that
    // brakes it is applied from now on. `aUp` / `aDown` are how hard the button pushes up / down.
    static double restOffset(double vn, double aUp, double aDown) {
        return vn < 0.0 ? -vn * vn / (2.0 * aUp) : vn * vn / (2.0 * aDown);
    }

    // Per-tick bookkeeping; returns this tick's vertical speed.
    double observe(double y, double up, Fly mode) {
        double v = haveY_ ? y - lastY_ : 0.0;
        lastY_ = y;
        haveY_ = true;
        ++since_;
        const bool same = up == up_;
        up_ = up;
        bool usable = true;
        if (std::fabs(v) > kTeleport) {          // portal, teleport, respawn: hold the new height
            target_ = y;
            v = 0.0;
            usable = false;
        } else if (haveV_ && same) {
            learn((v - lastV_) * up, v * up, mode);
        } else if (tapPending_ && mode == Fly::Ufo && same) {
            learnTap(v * up);
        }
        tapPending_ = false;
        flipPending_ = false;
        lastV_ = v;
        haveV_ = usable;
        return v;
    }

    // One acceleration sample `dv` (up-positive); the force behind it is the one in force during the last tick.
    void learn(double dv, double vn, Fly mode) {
        switch (mode) {
            case Fly::Ship:
                if (held_ && dv > kMinSample) ema(accUp_, nUp_, dv);
                else if (!held_ && dv < -kMinSample) ema(accDown_, nDown_, -dv);
                break;
            case Fly::Ufo:
                if (tapPending_) learnTap(vn);
                else if (dv < -kMinSample) ema(grav_, nGrav_, -dv);
                break;
            case Fly::Swing:
                if (!flipPending_ && std::fabs(dv) > kMinSample) {
                    accSign_ = dv > 0.0 ? 1 : -1;
                    ema(gSwing_, nSwing_, std::fabs(dv));
                }
                break;
            default: break;
        }
    }

    void learnTap(double vn) {
        const double sample = vn + grav_;        // the tick that applied the jump also applied one step of gravity
        if (sample > kMinSample) ema(tapV_, nTap_, sample);
    }

    static void ema(double& value, int& count, double sample) {
        if (count == 0) value = sample;
        else if (value > 0.0 && sample > 4.0 * value) return;      // collision / clamp artefact
        else value += 0.25 * (sample - value);
        if (count < 1000) ++count;
    }

    int press() {
        held_ = true;
        since_ = 0;
        tapPending_ = true;
        flipPending_ = true;
        accSign_ = -accSign_;                    // swing: the tap flips gravity (re-measured on the next tick)
        return 1;
    }
    int release() {
        held_ = false;
        since_ = 0;
        return -1;
    }
    int switchTo(bool want, int minTicks) {
        if (want == held_ || since_ < minTicks) return 0;
        return want ? press() : release();
    }

    StraightLaw law_ = StraightLaw::Predictive;
    double target_ = 0.0, lastY_ = 0.0, lastV_ = 0.0, up_ = 1.0;
    bool haveY_ = false, haveV_ = false, held_ = false, tapPending_ = false, flipPending_ = false;
    int since_ = 1 << 20;
    double accUp_ = 0.0, accDown_ = 0.0, grav_ = 0.0, tapV_ = 0.0, gSwing_ = 0.0;
    int nUp_ = 0, nDown_ = 0, nGrav_ = 0, nTap_ = 0, nSwing_ = 0;
    int accSign_ = 0;                            // swing: +1 gravity currently pulls up, -1 down, 0 not known yet
};

}  // namespace fa
