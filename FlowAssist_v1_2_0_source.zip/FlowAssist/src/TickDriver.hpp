#pragma once

// Flow Assist - the per-tick glue between the rhythm engine and the tick-grid drive.
//
// Pure C++20 (no Geode): Hooks.cpp feeds it one PlayerView per physics tick and sends whatever it answers; the
// unit tests feed it simulated players. Keeping it here means the logic that decides every click in the game is
// the logic the tests run.

#include <algorithm>
#include <cmath>
#include <cstdint>

#include "AssistEngine.hpp"
#include "TickDrive.hpp"

namespace fa {

// What the driver needs to know about the player it is assisting.
struct PlayerView {
    Fly mode = Fly::None;   // None = cube, ball, robot or spider
    double y = 0.0;         // height in game units
    double up = 1.0;        // +1 normal gravity, -1 upside down
};

class TickDriver {
public:
    static constexpr double kHoldFraction = 0.4;   // plain rhythm: share of each click period the button is down

    void reset() { *this = TickDriver{}; }
    void idle() { running_ = false; }   // not assisting this tick (cheaper than reset(); step() restarts cleanly)

    // Call once per physics tick (a repeated tick number, as the two halves of a half-tick pass, is ignored).
    // Returns +1 to press, -1 to release, 0 to leave the button alone, for the side the engine is assisting.
    int step(Engine& engine, StraightConfig const& sc, std::uint32_t tick, PlayerView const& pv) {
        if (tick == lastTick_) return 0;
        lastTick_ = tick;

        if (!engine.active()) {
            running_ = false;
            return 0;
        }
        const bool straight = sc.enabled && isFlying(pv.mode);

        if (!running_ || pv.mode != mode_ || straight != straight_) {
            // (Re)start at the current height and tick. The press that switched the assist on is the first click.
            running_ = true;
            mode_ = pv.mode;
            straight_ = straight;
            const bool down = engine.gameButtonDown();
            if (straight) {
                level_.setLaw(sc.law);
                level_.start(pv.y, down);
            } else {
                rhythm_.begin(tick, kTps / engine.rhythmCps(), kHoldFraction, down);
            }
            engine.setStraightShown(straight);
            return 0;
        }

        int action = 0;
        if (straight) {
            level_.setLaw(sc.law);
            const double period = kTps / std::max(sc.cpsFor(pv.mode), 1.0);
            const int half = std::max(1, static_cast<int>(std::lround(period / 2.0)));   // shortest press / release
            const int gap = std::max(2, static_cast<int>(std::lround(period)));          // shortest click-to-click
            switch (pv.mode) {
                case Fly::Ship: action = level_.stepShip(pv.y, pv.up, half); break;
                case Fly::Wave: action = level_.stepWave(pv.y, pv.up, half); break;
                case Fly::Ufo: action = level_.stepUfo(pv.y, pv.up, gap); break;
                default: action = level_.stepSwing(pv.y, gap); break;
            }
        } else {
            action = rhythm_.step(tick, kTps / engine.rhythmCps(), kHoldFraction);
        }
        if (action != 0) engine.noteDriven(action > 0);
        return action;
    }

    bool running() const { return running_; }
    bool straight() const { return straight_; }
    Leveler const& leveler() const { return level_; }

private:
    bool running_ = false;
    bool straight_ = false;
    Fly mode_ = Fly::None;
    std::uint32_t lastTick_ = ~0u;
    Leveler level_;
    TickRhythm rhythm_;
};

}  // namespace fa
