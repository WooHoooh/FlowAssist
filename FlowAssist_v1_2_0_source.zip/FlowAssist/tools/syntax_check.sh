#!/bin/sh
# Syntax/type check of the Geode-facing sources (Shared, Hooks, Hud, main) against the hand-written stand-in
# headers in tests/stubs. Catches typos and signature mismatches inside Flow Assist's own code only; it is NOT a
# substitute for the real build (GitHub Actions), because the stand-ins are written from how the code uses the SDK.
# SettingWidgets.cpp is not covered (it needs a much larger part of the SDK).
set -e
cd "$(dirname "$0")/.."
for f in src/Shared.cpp src/Hooks.cpp src/Hud.cpp src/main.cpp; do
  echo "syntax-check $f"
  g++ -std=c++23 -fsyntax-only -Wall -Wextra -Werror -Wno-unused-parameter -I tests/stubs -I src "$f"
done
echo "syntax_check.sh: OK"
