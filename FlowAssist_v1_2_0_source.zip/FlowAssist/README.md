# Flow Assist

By **Lumin**. A Geometry Dash 2.2081 [Geode](https://geode-sdk.org) mod. Spam the jump button faster than your
**Activation CPS** and Flow Assist takes over the clicks: a steady rhythm in cube / ball / robot / spider, and
**dead-level flight in ship, wave, UFO and swing** (Go Straight). It stops as soon as you stop clicking, slow down, or
hold the button. Built to coexist with **Afterflow**. Targets only **Windows x64** and **Android ARM64**.

Continues Alternate Assist (the same code that Voidius is built from). See `changelog.md`.

---

## Status: read this first

| Item | State |
|---|---|
| Source, unit tests, static checks | Done and run (see `TEST_AND_BUILD_REPORT.md`). |
| **Windows x64 `.geode`** | **Not built here.** The build machine had no network, Geode SDK, MSVC / clang-cl or cmake. |
| **Android ARM64 `.geode`** | **Not built here**, same reason. |
| In-game testing (either platform, with or without Afterflow) | **Not done.** Nothing here ran inside Geometry Dash. |

To get both `.geode` files: push this folder to a GitHub repository. `.github/workflows/build.yml` builds Android
ARM64 and Windows x64 with `geode-sdk/build-geode-mod` and uploads them as artifacts (Actions tab -> latest run ->
`flow-assist-android-arm64`, `flow-assist-windows-x64`). The v1.1.0 `.geode` you supplied contains only an Android
binary, so earlier you most likely downloaded only that artifact: download **both** this time.

## Go Straight

While the assist is active in a flying gamemode, every physics tick (240 per second) it looks at the player's height
and decides whether the button should be down, so the player stays at the height it had when the assist took over.
It never clicks faster than that gamemode's CPS limit, so it still looks and feels like spam, just level.

| Mode | What it does |
|---|---|
| Ship | Press/release so the player would come to rest on the target (Predictive) or on a fixed look-ahead (Classic). |
| Wave | Switch when the wave crosses the target. The zig-zag is as tall as one click is long, so it is limited only by the CPS limit: **raise Wave CPS for a straighter wave**. |
| UFO | Tap when a jump arc started now would be centred on the target. One jump arc is the physical minimum for a UFO, so peak-to-peak cannot shrink, but the arc is centred. |
| Swing | Flip gravity so the player comes to rest at the target. Needs a tick or two to see which way gravity pulls before it flips. |
| Cube, ball, robot, spider | Plain steady rhythm on the tick grid (rate from Target CPS and Assistance Strength). |

**Straight Engine** setting:

* **Predictive** (default): learns how hard the button pushes the player from the heights it observes each tick, so it
  needs no gamemode constants and follows speed, mini and size changes. Until it has enough measurements, or if the
  measurements look implausible, it answers exactly like Classic.
* **Classic**: the Alternate Assist / Voidius law, reproduced action-for-action (tested). Pick it if Predictive ever
  misbehaves in a particular level.

A big jump in height (portal, teleport, respawn) re-centres the target on the new height. A gravity flip is handled.

## Afterflow compatibility

[Afterflow](https://github.com/afterflow-gd/afterflow) (id `afterflow.prsevend`) is a predictive input buffer. Its source
was not available, so this rests on its README and on how such mods work, **not on its code**.

* Default **Yield**: with Afterflow loaded, Flow Assist never activates, never injects an input and never swallows
  one, so Afterflow sees exactly what it would see without Flow Assist (the new tick hook then only calls the
  original). Test 8f in `tests/engine_test.cpp` checks this on a model.
* **Share** (experimental): both run; Flow Assist backs off by itself if it sees input being re-sent behind its back.
* v1.2.0 adds **one new hook**, `GJBaseGameLayer::processCommands` (needed to click on physics ticks and read the
  player's height every tick). Alternate Assist / Voidius use the same hook and are documented as working with
  Afterflow, but whether the two hooks interact badly was **not tested in game**. If you see trouble, keep Yield.
* The only thing asked of Geode about Afterflow is `Loader::isModLoaded("afterflow.prsevend")`.

## Settings (Mods -> Flow Assist -> Settings)

| Setting | Default | Meaning |
|---|---|---|
| Enable Flow Assist | on | Master switch. |
| Activation CPS | 8 | Click speed that switches the assist on. |
| Target CPS | 12 | Rate of the plain rhythm (cube, ball, robot, spider, or Go Straight off). |
| Assistance Strength | 60 % | 0 = even out your own pace, 100 = lock to Target CPS. |
| Go Straight | on | Level flight in ship, wave, UFO, swing. |
| Straight Engine | Predictive | Predictive or Classic (Voidius law). |
| Ship / Wave / UFO / Swing CPS | 20 / 15 / 12 / 12 | Fastest click rate while flying that gamemode. Higher is straighter. |
| Live CPS, Assist Status | | Readouts with a TAP pad to try the threshold without a level. |
| Show HUD, HUD Position | on, Top Left | In-level overlay; shows `STRAIGHT` while flying level. |
| Hold Detection | 110 ms | Holding this long hands the button back to you. |
| Afterflow Mode | Yield | Yield or Share (only used when Afterflow is loaded). |

Settings saved by Alternate Assist do not carry over (different mod id), and the v1.1.0 settings stay as they were.

## Build (Windows x64 + Android ARM64)

**GitHub Actions (no local toolchain; works from a phone)**
1. Create a repository, upload the contents of this folder (keep `.github/workflows/build.yml`).
2. Actions tab -> *Build Flow Assist* -> run (or just push).
3. Download the artifacts `flow-assist-android-arm64` and `flow-assist-windows-x64` (each holds a `.geode`).

**Local:** install the Geode SDK + CLI, set `GEODE_SDK`, then `geode build` (Windows, MSVC x64) or
`geode build --platform android64` (Android NDK). CMake refuses any other platform.

**Install:** copy the `.geode` into the `geode/mods` folder of the game (Android: the game's `geode/mods` directory;
Windows: `<GD folder>\geode\mods`) and restart the game. The icon is `logo.png` (your supplied logo, 336x336).

## On-device checklist (run on BOTH platforms; none of this has been run)

1. Mod list shows Flow Assist by Lumin with the purple fast-forward icon.
2. Settings page opens; TAP pad shows CPS; Reset to Defaults works.
3. Ship section: spam above the threshold; the HUD shows `STRAIGHT`, the ship stays level. Repeat in wave, UFO, swing.
4. Cube section: HUD shows `ASSIST`, clicks are even.
5. Stop spamming: control returns within about 0.4 s and the button is not stuck. Hold the button: handed back at once.
6. Portal ship -> wave -> cube while spamming: no stuck button.
7. Death / restart while the assist is active: next attempt starts clean.
8. Afterflow installed, Yield: behaviour identical to Afterflow alone. Then try Share.
9. If a level behaves oddly with Predictive, switch Straight Engine to Classic and compare.

## Where to look first if the CI build fails

1. `Hooks.cpp`: `processCommands` override and the `PlayerObject` flags `m_isShip m_isDart m_isBird m_isSwing m_isUpsideDown`
   (same names Alternate Assist used and compiled with).
2. `Shared.cpp`: `m_queuedButtons` / `m_timestamp` (copied from Alternate Assist), `isModLoaded`, `getSettingValue<std::string>`.
3. `SettingWidgets.cpp`: only the status text changed (one extra state).

## Measurements (host simulation; `tests/straight_test.cpp`)

Simulated plants, not Geometry Dash. They show how the law behaves on those models, not the numbers you will see in game.
Baseline = the Alternate Assist / Voidius law, run on the same plants and CPS limits.

| Gamemode (runs) | Peak-to-peak height | Mean distance from level |
|---|---|---|
| Ship (90) | 4.26 -> 3.37 (-21 %) | 6.88 -> 4.85 (-29 %) |
| Wave (12) | 15.6 -> 15.6 (at its floor for the CPS limit) | 13.65 -> 13.65 |
| UFO (24) | 40.2 -> 40.4 (a jump arc is the minimum) | 66.9 -> 20.4 (-69 %) |
| Swing (12) | baseline diverges on these plants (2213) -> 45 | 2912 -> 27 |

Plain-rhythm timing, worst click-to-click error vs the ideal period (v1.1.0 frame-aware vs tick grid):
60 FPS 14 CPS 11.9 ms -> 3.6 ms; 60 FPS 17 CPS 8.8 -> 3.7 ms; 144 FPS 14 CPS 4.8 -> 3.6 ms (12 CPS: both 0).

## Known limitations

* No `.geode` was compiled here; nothing was tested in the game or with the real Afterflow.
* The Predictive law assumes the ship's push is roughly constant per tick. Real GD physics has clamps, slopes, orbs and
  pads that the simulated plants do not; the law re-measures continuously and falls back to Classic, but real-level
  results can differ.
* Swing's swing-gravity direction is *measured*, not assumed, so the first tick or two after activation do nothing.
* The straightness reference video could not be measured automatically (see the report); the numbers above come from
  simulation.
* Peak-to-peak in wave is set by the CPS limit; UFO has a physical floor of one jump arc.
* Share mode remains experimental.

## Reproduce the standalone checks

```
python3 tools/check_defaults.py
g++ -std=c++20 -O2 -Wall -Wextra -Werror -I src tests/engine_test.cpp -o engine_test && ./engine_test
g++ -std=c++20 -O2 -Wall -Wextra -Werror -I src tests/straight_test.cpp -o straight_test && ./straight_test
g++ -std=c++20 -O2 -I src -I tests tests/compare_test.cpp -o compare_test && ./compare_test
sh tools/syntax_check.sh
```

## Layout

`src/AssistEngine.hpp` activation / hand-back / two-finger / co-op logic (pure C++) - `src/TickDrive.hpp` tick rhythm +
Go Straight leveler (pure) - `src/TickDriver.hpp` per-tick glue (pure) - `src/Hooks.cpp` the only input hooks -
`src/Shared.*` settings and injection - `src/Hud.cpp`, `src/SettingWidgets.cpp` UI - `tests/` host tests, stubs,
baselines (`AlternateLeveler.hpp` is the Voidius law, verbatim) - `branding/` original logo files - `reports/`.
