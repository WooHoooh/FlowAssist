# Flow Assist

By **Lumin**. Keeps fast clicking and two-finger alternation at a **steady rhythm**.

Click faster than your **Activation CPS** and the assist takes over the *timing* of your clicks, firing them
evenly at your **Target CPS** until you stop, slow down, or hold the button. Below the threshold, or with the mod
disabled, every click reaches the game exactly as you made it.

## Go Straight

In **ship, wave, UFO and swing** the assist keeps you at the height you were at when it took over, instead of
clicking a fixed rhythm that drifts up or down. Each gamemode has its own click limit (**Ship / Wave / UFO / Swing CPS**);
higher is straighter, because a wave's zig-zag is as tall as one click is long. **Straight Engine** chooses
*Predictive* (default) or *Classic* (the original Alternate Assist / Voidius behaviour). Cube, ball, robot and spider
use the plain rhythm.

## Works with Afterflow

If **Afterflow** is also installed, Flow Assist **yields** by default: it leaves your input completely alone so
Afterflow behaves exactly as it does on its own (the HUD shows `AFTERFLOW`). *Afterflow Mode: Share* is an
experimental option that lets both run at once; Flow Assist then backs off by itself if it sees input being re-sent.

## Settings

- **Activation CPS** - the click speed that switches the assist on.
- **Target CPS** - the speed it aims for.
- **Assistance Strength** - 0% evens out your own pace, 100% locks to the target.
- **Live CPS / Assist Status** - live readout with a **TAP pad** to try it without starting a level.
- **HUD** - a small in-level overlay with your CPS and the assist status.
- **Go Straight / Straight Engine / Ship, Wave, UFO, Swing CPS** - see above.
- **Hold Detection** - how long you must hold the button before the assist hands it back to you.
- **Afterflow Mode** - Yield (default) or Share.
- **Reset to Defaults**.

## Good to know

- Only the jump button is affected. The editor and platformer left/right are untouched.
- This changes your input, like any assist. Don't use it where leaderboard or verification rules forbid it.
- Works best at 60+ FPS (the faster the frame rate, the steadier the rhythm).
