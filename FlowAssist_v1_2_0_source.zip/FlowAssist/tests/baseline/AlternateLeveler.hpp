#pragma once
// BASELINE ONLY - used by tests/straight_test.cpp to compare against.
// This is the Leveler of Alternate Assist v1.6.1 (the Voidius behaviour), copied verbatim from
// alternate-assist-source.zip: altassist/src/assist.hpp. Do not edit; do not include from src/.

#include <algorithm>
#include <cmath>

namespace aa {

// Keeps a flying player at the height the assist took over at. Each tick it looks at where the
// player is heading and decides whether the button should be down, but never switches faster
// than the spam speed allows, so it still clicks like spam, just level.
struct Leveler {
    double target = 0.0;
    double lastY = 0.0;
    bool held = false;
    int sinceSwitch = 1 << 20;

    void start(double y) {
        target = lastY = y;
        held = false;
        sinceSwitch = 1 << 20;
    }

    // Shared bookkeeping; returns this tick's vertical speed. A big jump in height is a
    // teleport or portal, so the new height becomes the one to hold.
    double observe(double y) {
        double vy = y - lastY;
        lastY = y;
        if (std::abs(vy) > 40.0) {
            target = y;
            vy = 0.0;
        }
        ++sinceSwitch;
        return vy;
    }

    int change(bool want) {
        held = want;
        sinceSwitch = 0;
        return want ? 1 : -1;
    }

    // Ship, wave: hold while heading below the target. `up` is +1 when pressing moves the
    // player up on screen (normal gravity), -1 when flipped. `minTicks` = shortest press/release.
    int stepHold(double y, double up, double lookahead, int minTicks) {
        double vy = observe(y);
        bool want = (target - (y + vy * lookahead)) * up > 0.0;
        if (want != held && sinceSwitch >= minTicks) return change(want);
        return 0;
    }

    // UFO: a short tap whenever it's heading below the target, at most one every `minGap` ticks.
    int stepTap(double y, double up, double lookahead, int minGap) {
        double vy = observe(y);
        if (held) return sinceSwitch >= 1 ? change(false) : 0;
        bool want = (target - (y + vy * lookahead)) * up > 0.0;
        return want && sinceSwitch >= minGap ? change(true) : 0;
    }

    // Swing: a tap flips gravity, so flip whenever it's moving away from the target.
    int stepFlip(double y, double deadzone, int minGap) {
        double vy = observe(y);
        if (held) return sinceSwitch >= 1 ? change(false) : 0;
        bool away = (y < target - deadzone && vy < 0.0) || (y > target + deadzone && vy > 0.0);
        return away && sinceSwitch >= minGap ? change(true) : 0;
    }
};

} // namespace aa
