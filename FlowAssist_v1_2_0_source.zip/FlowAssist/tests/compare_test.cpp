// A/B measurements: original Alternate Assist engine (tests/baseline, namespace aa) versus the new
// Flow Assist engine (src, namespace fa), fed IDENTICAL simulated input.
//
// This is a model of the game loop (frame-stamped input, optional frame-time jitter), not Geometry Dash
// itself. It exists so that every claimed improvement is a number that can be reproduced, and so that a
// change that does not help shows up as such.
//
// Build & run:  g++ -std=c++20 -O2 -Wall -Wextra -I src -I tests tests/compare_test.cpp -o compare_test && ./compare_test

#include "../src/AssistEngine.hpp"
#include "baseline/AssistEngine_v1.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <functional>
#include <random>
#include <vector>

struct V1 {
    using Engine = aa::Engine;
    using Config = aa::Config;
    static constexpr aa::Action Press = aa::Action::Press;
    static constexpr aa::Action Release = aa::Action::Release;
    static constexpr const char* name = "v1";
};
struct V2 {
    using Engine = fa::Engine;
    using Config = fa::Config;
    static constexpr fa::Action Press = fa::Action::Press;
    static constexpr fa::Action Release = fa::Action::Release;
    static constexpr const char* name = "v2";
};

struct GameEv {
    double t;
    bool down;
    bool injected;
};

template <class NS>
struct Sim {
    typename NS::Engine eng;
    std::vector<GameEv> game;
    bool gameDown = false;
    int activations = 0;
    int deactivations = 0;
    double activeFrames = 0, frames = 0;

    void emit(double t, bool down, bool injected) {
        gameDown = down;
        game.push_back({t, down, injected});
    }
    void press(double t) {
        const auto r = eng.onRealPress(t, true);
        if (r.activated) ++activations;
        if (r.preRelease) emit(t, false, true);
        if (r.forward) emit(t, true, false);
    }
    void release(double t) {
        const auto r = eng.onRealRelease(t);
        if (r.forward) emit(t, false, false);
    }
    void tick(double t) {
        const auto o = eng.tick(t);
        if (o.deactivated) ++deactivations;
        if (o.action == NS::Press) emit(t, true, true);
        else if (o.action == NS::Release) emit(t, false, true);
        frames += 1;
        if (eng.active()) activeFrames += 1;
    }
};

struct RealEv {
    double t;
    bool press;
};

// Frame timestamps with vsync-style noise: each frame lands within +-jitterFrac of a frame of its ideal time.
static std::vector<double> frameTimes(double fps, double tEnd, double jitterFrac, std::mt19937& rng) {
    std::vector<double> f;
    std::uniform_real_distribution<double> u(-jitterFrac, jitterFrac);
    const double fd = 1.0 / fps;
    for (long k = 0;; ++k) {
        const double t = static_cast<double>(k) * fd + (k == 0 ? 0.0 : u(rng) * fd);
        if (t > tEnd) break;
        f.push_back(t);
    }
    return f;
}

template <class NS>
static void run(Sim<NS>& s, std::vector<RealEv> const& evs, std::vector<double> const& frames) {
    size_t i = 0;
    for (double f : frames) {
        while (i < evs.size() && evs[i].t <= f + 1e-12) {
            if (evs[i].press) s.press(f);   // the game dispatches input once per frame, stamped with that frame
            else s.release(f);
            ++i;
        }
        s.tick(f);
    }
}

static std::vector<RealEv> train(double start, double rate, int n, double tap, double jitter, std::mt19937& rng) {
    std::vector<RealEv> v;
    std::uniform_real_distribution<double> u(-1.0, 1.0);
    double t = start;
    for (int i = 0; i < n; ++i) {
        const double interval = (1.0 / rate) * (1.0 + (jitter > 0 ? jitter * u(rng) : 0.0));
        v.push_back({t, true});
        v.push_back({t + std::min(tap, 0.7 * interval), false});
        t += interval;
    }
    return v;
}

static double mean(std::vector<double> const& v) {
    if (v.empty()) return 0;
    double s = 0;
    for (double x : v) s += x;
    return s / static_cast<double>(v.size());
}
static double pct(std::vector<double> v, double p) {
    if (v.empty()) return 0;
    std::sort(v.begin(), v.end());
    return v[std::min(v.size() - 1, static_cast<size_t>(p * static_cast<double>(v.size())))];
}
static double cvOf(std::vector<double> const& d) {
    if (d.size() < 3) return 0;
    const double m = mean(d);
    double var = 0;
    for (double x : d) var += (x - m) * (x - m);
    return std::sqrt(var / static_cast<double>(d.size())) / m;
}

// Share of presses whose length is the most common whole number of frames (1.0 = every press identical).
static double modalShare(std::vector<double> const& lengths, double fps) {
    if (lengths.empty()) return 0;
    std::vector<int> counts(64, 0);
    for (double w : lengths) {
        const long f = std::lround(w * fps);
        ++counts[static_cast<size_t>(std::min<long>(std::max<long>(f, 0), 63))];
    }
    return static_cast<double>(*std::max_element(counts.begin(), counts.end())) / static_cast<double>(lengths.size());
}

// Intervals between game presses (any source) inside [from, to).
template <class NS>
static std::vector<double> pressIntervals(Sim<NS> const& s, double from, double to) {
    std::vector<double> t, d;
    for (auto const& e : s.game)
        if (e.down && e.t >= from && e.t < to) t.push_back(e.t);
    for (size_t i = 1; i < t.size(); ++i) d.push_back(t[i] - t[i - 1]);
    return d;
}
// Press lengths (down -> next up) for presses inside [from, to).
template <class NS>
static std::vector<double> dwells(Sim<NS> const& s, double from, double to, bool injectedOnly) {
    std::vector<double> d;
    for (size_t i = 0; i + 1 < s.game.size(); ++i)
        if (s.game[i].down && !s.game[i + 1].down && s.game[i].t >= from && s.game[i].t < to &&
            (!injectedOnly || s.game[i].injected))
            d.push_back(s.game[i + 1].t - s.game[i].t);
    return d;
}

// ------------------------------------------------------------------------------------------
// 1. How well is CPS measured from frame-stamped presses?
//    Truth = rate over the same presses using their true (unquantised) times, the quantity a
//    perfect clock would report. Engines are disabled so only the measurement is compared.
// ------------------------------------------------------------------------------------------
template <class NS>
static std::vector<double> measureErrors(double fps, double jitter, std::mt19937& rng) {
    typename NS::Config off;
    off.enabled = false;
    std::vector<double> errs;
    const double fd = 1.0 / fps;
    for (int seed = 0; seed < 30; ++seed) {
        typename NS::Engine e;
        e.setConfig(off);
        std::uniform_real_distribution<double> u(-1.0, 1.0);
        std::vector<double> truth;
        double t = 0.3;
        for (int i = 0; i < 60; ++i) {
            const double rate = 8.0 + 8.0 * ((seed * 7 + 3) % 10) / 10.0;   // 8..15.2 CPS
            truth.push_back(t);
            const double stamp = std::ceil(t / fd) * fd;
            e.onRealPress(stamp, true);
            // true rate over the burst the engine sees: same presses, exact times (1 s window)
            size_t first = truth.size() - 1;
            while (first > 0 && truth.back() - truth[first - 1] <= 1.0 && truth[first] - truth[first - 1] <= 0.6) --first;
            const size_t m = truth.size() - first;
            if (i >= 12 && m >= 3) {
                const double trueRate = static_cast<double>(m - 1) / (truth.back() - truth[first]);
                errs.push_back(std::fabs(e.cps(stamp) - trueRate) / trueRate);
            }
            t += (1.0 / rate) * (1.0 + (jitter > 0 ? jitter * u(rng) : 0.0));
        }
    }
    return errs;
}

static void compare_measurement() {
    std::printf("[A] CPS measurement error vs the true rate (frame-stamped presses; lower is better)\n");
    std::printf("      %-34s %12s %12s\n", "scenario", "v1 mean/p95", "v2 mean/p95");
    for (double jitter : {0.0, 0.15, 0.25}) {
        for (double fps : {30.0, 60.0, 144.0}) {
            std::mt19937 r1(11), r2(11);
            const auto a = measureErrors<V1>(fps, jitter, r1);
            const auto b = measureErrors<V2>(fps, jitter, r2);
            char label[64];
            std::snprintf(label, sizeof label, "%3.0f FPS, +-%2.0f%% click jitter", fps, jitter * 100);
            std::printf("      %-34s %5.2f/%5.2f%% %5.2f/%5.2f%%\n", label, mean(a) * 100, pct(a, 0.95) * 100, mean(b) * 100,
                        pct(b, 0.95) * 100);
        }
    }
}

// ------------------------------------------------------------------------------------------
// 2. Straightness of the assist's output (identical jittery frame times for both engines)
// ------------------------------------------------------------------------------------------
template <class NS>
static void straightness(double fps, double target, std::vector<double>& intervalCv, std::vector<double>& dwellShare,
                         std::vector<double>& dwellMean, double tap = 0.045, double playerRate = 9.0, double playerJitter = 0.0) {
    for (int seed = 0; seed < 12; ++seed) {
        std::mt19937 rng(static_cast<unsigned>(1000 + seed));
        Sim<NS> s;
        typename NS::Config c;
        c.activationCps = 8;
        c.targetCps = target;
        c.strength = 1.0;
        s.eng.setConfig(c);
        auto ev = train(0.2, playerRate, 50, tap, playerJitter, rng);
        const auto frames = frameTimes(fps, 6.0, 0.08, rng);   // +-8 % of a frame of timing noise
        run(s, ev, frames);
        const auto d = pressIntervals(s, 1.5, 4.5);
        intervalCv.push_back(cvOf(d));
        const auto w = dwells(s, 1.5, 4.5, true);
        dwellShare.push_back(modalShare(w, fps));
        dwellMean.push_back(mean(w));
    }
}

static void compare_straightness() {
    std::printf("[B] Straightness of the output: press-interval CV (lower is better) / presses with the same length in frames (higher is better)\n");
    std::printf("      %-30s %-19s %-19s\n", "target CPS @ FPS", "v1 interval / same-len", "v2 interval / same-len");
    const struct { double fps, target; } cases[] = {{60, 10}, {60, 12}, {60, 13.7}, {60, 15}, {60, 20}, {90, 12}, {90, 15},
                                                   {120, 12}, {120, 13.7}, {144, 12}, {144, 13.7}, {240, 12}, {240, 13.7}};
    double sum1 = 0, sum2 = 0, l1 = 0, l2 = 0;
    for (auto const& k : cases) {
        std::vector<double> i1, d1, m1, i2, d2, m2;
        straightness<V1>(k.fps, k.target, i1, d1, m1);
        straightness<V2>(k.fps, k.target, i2, d2, m2);
        char label[48];
        std::snprintf(label, sizeof label, "%5.1f CPS @ %3.0f FPS", k.target, k.fps);
        std::printf("      %-30s %6.3f / %5.1f%%    %6.3f / %5.1f%%\n", label, mean(i1), mean(d1) * 100, mean(i2), mean(d2) * 100);
        sum1 += mean(i1); sum2 += mean(i2); l1 += mean(d1); l2 += mean(d2);
    }
    const double n = static_cast<double>(sizeof(cases) / sizeof(cases[0]));
    std::printf("      %-30s %6.3f / %5.1f%%    %6.3f / %5.1f%%\n", "average over the cases", sum1 / n, l1 / n * 100, sum2 / n, l2 / n * 100);
}

// Slow tappers (finger down 70 ms): does the output press length follow the finger?
static void compare_slow_tapper() {
    std::printf("[C] Assist press length vs how long the player's finger stays down (player 9 CPS, target 12, 60 FPS)\n");
    for (double tap : {0.03, 0.05, 0.07, 0.09}) {
        std::vector<double> i1, d1, m1, i2, d2, m2;
        straightness<V1>(60, 12, i1, d1, m1, tap);
        straightness<V2>(60, 12, i2, d2, m2, tap);
        std::printf("      finger down %3.0f ms: v1 length %5.1f ms, %5.1f%% identical   v2 length %5.1f ms, %5.1f%% identical\n", tap * 1000,
                    mean(m1) * 1000, mean(d1) * 100, mean(m2) * 1000, mean(d2) * 100);
    }
}

// ------------------------------------------------------------------------------------------
// 3. Two-finger alternation: presses overlap, so one finger is always down
// ------------------------------------------------------------------------------------------
template <class NS>
static void alternation(double rate, double fps, double& activeFrac, double& activationsPerRun, double& releasedMs) {
    double af = 0, act = 0, rel = 0;
    const int runs = 20;
    for (int seed = 0; seed < runs; ++seed) {
        std::mt19937 rng(static_cast<unsigned>(50 + seed));
        std::uniform_real_distribution<double> u(-0.1, 0.1);
        Sim<NS> s;
        typename NS::Config c;
        c.activationCps = 8;
        c.targetCps = rate + 2;
        c.strength = 0.6;
        s.eng.setConfig(c);
        // finger A and finger B take turns; each stays down about 1.2 intervals, so every press lands while
        // the other finger is still down
        std::vector<RealEv> ev;
        double t = 0.3;
        for (int i = 0; i < 70; ++i) {
            const double interval = (1.0 / rate) * (1.0 + u(rng));
            ev.push_back({t, true});
            ev.push_back({t + 1.2 * interval, false});
            t += interval;
        }
        std::stable_sort(ev.begin(), ev.end(), [](RealEv const& a, RealEv const& b) { return a.t < b.t; });
        run(s, ev, frameTimes(fps, t + 0.6, 0.05, rng));
        // we are interested in the middle of the spam
        af += s.frames > 0 ? s.activeFrames / s.frames : 0;
        act += s.activations;
        // time the game button spent up during the spam window (a stuck-on-and-off pattern shows up here)
        double up = 0;
        for (size_t i = 0; i + 1 < s.game.size(); ++i)
            if (!s.game[i].down && s.game[i + 1].down && s.game[i].t > 1.5 && s.game[i].t < 4.0) up += s.game[i + 1].t - s.game[i].t;
        rel += up;
    }
    activeFrac = af / runs;
    activationsPerRun = act / runs;
    releasedMs = rel / runs * 1000;
}

static void compare_alternation() {
    std::printf("[D] Two-finger overlapping alternation, 70 clicks per run, 60 FPS\n");
    std::printf("      %-12s %-30s %-30s\n", "click rate", "v1 active / activations per run", "v2 active / activations per run");
    for (double rate : {9.0, 11.0, 13.0, 16.0}) {
        double a1, n1, r1, a2, n2, r2;
        alternation<V1>(rate, 60, a1, n1, r1);
        alternation<V2>(rate, 60, a2, n2, r2);
        std::printf("      %5.1f CPS    %5.1f%% of frames / %6.1f          %5.1f%% of frames / %6.1f\n", rate, a1 * 100, n1, a2 * 100, n2);
    }
}

// ------------------------------------------------------------------------------------------
// 4. Spam -> deliberate hold: how long does the game see the button UP before the hold takes over?
// ------------------------------------------------------------------------------------------
template <class NS>
static double holdGap(double tap, double fps, std::vector<double>* all = nullptr) {
    double worst = 0;
    for (int phase = 0; phase < 24; ++phase) {
        std::mt19937 rng(7);
        Sim<NS> s;
        typename NS::Config c;
        c.activationCps = 8;
        c.targetCps = 12;
        c.strength = 1.0;
        s.eng.setConfig(c);
        auto ev = train(0.2, 10.0, 25, tap, 0.0, rng);
        const double holdAt = ev.back().t + 0.1 + phase * 0.004;
        ev.push_back({holdAt, true});
        ev.push_back({holdAt + 0.5, false});
        std::vector<double> frames;
        for (long k = 0; k * (1.0 / fps) <= holdAt + 1.2; ++k) frames.push_back(static_cast<double>(k) / fps);
        run(s, ev, frames);
        double up = 0;
        bool downSeen = false;
        double lastDown = -1;
        for (auto const& g : s.game) {
            if (g.t < holdAt - 1e-9) continue;
            if (g.down) { if (lastDown < 0 && downSeen) {} downSeen = true; }
        }
        // time during [holdAt, holdAt+0.5) that the game believed "up"
        double prevT = holdAt;
        bool state = false;
        for (auto const& g : s.game) {
            if (g.t < holdAt - 1e-9) { state = g.down; continue; }
            if (g.t >= holdAt + 0.5) break;
            if (!state) up += g.t - prevT;
            prevT = g.t;
            state = g.down;
        }
        if (!state) up += holdAt + 0.5 - prevT;
        worst = std::max(worst, up);
        if (all) all->push_back(up);
        (void)lastDown;
    }
    return worst;
}

static void compare_hold_handover() {
    std::printf("[E] Spam then deliberate hold: worst time the game saw the button UP during the hold (24 phases)\n");
    for (double tap : {0.03, 0.05, 0.07, 0.09}) {
        std::printf("      taps %3.0f ms: v1 60 FPS %5.1f ms / 144 FPS %5.1f ms    v2 60 FPS %5.1f ms / 144 FPS %5.1f ms\n", tap * 1000,
                    holdGap<V1>(tap, 60) * 1000, holdGap<V1>(tap, 144) * 1000, holdGap<V2>(tap, 60) * 1000, holdGap<V2>(tap, 144) * 1000);
    }
}

// ------------------------------------------------------------------------------------------
// 5. CPU cost (tick() called through a real call, as the mod does)
// ------------------------------------------------------------------------------------------
// The mod calls tick() from another translation unit, so it is a real call there. Force the same here for both
// engines; otherwise a small engine gets inlined into the benchmark loop and looks free.
template <class E>
[[gnu::noinline]] static auto callTick(E& e, double t) { return e.tick(t); }

template <class NS>
static double costPerFrame(bool activeRun) {
    using clock = std::chrono::steady_clock;
    typename NS::Engine e;
    typename NS::Config c;
    c.activationCps = 8;
    e.setConfig(c);
    double t = 0.0;
    double sink = 0;
    // warm up into the wanted state
    if (activeRun) {
        for (int i = 0; i < 12; ++i) { e.onRealPress(t, true); e.onRealRelease(t + 0.02); t += 0.09; for (int k = 0; k < 5; ++k) { (void)e.tick(t); t += 0.0042; } }
    }
    const long n = 3000000;
    const auto a = clock::now();
    for (long i = 0; i < n; ++i) {
        t += 1.0 / 240.0;
        if (activeRun && (i % 20) == 0) { e.onRealPress(t, true); e.onRealRelease(t + 0.01); }
        const auto o = callTick(e, t);
        sink += static_cast<double>(static_cast<int>(o.action));
        asm volatile("" ::: "memory");   // keep the optimiser from collapsing the loop
    }
    const double ns = std::chrono::duration<double, std::nano>(clock::now() - a).count() / static_cast<double>(n);
    if (sink < 0) std::printf("never\n");
    return ns;
}

static void compare_cost() {
    std::printf("[F] CPU cost per frame (240 FPS, best of 3)\n");
    for (bool act : {false, true}) {
        double b1 = 1e9, b2 = 1e9;
        for (int i = 0; i < 3; ++i) { b1 = std::min(b1, costPerFrame<V1>(act)); b2 = std::min(b2, costPerFrame<V2>(act)); }
        std::printf("      %-34s v1 %5.1f ns   v2 %5.1f ns\n", act ? "assist active, a press every 20 frames:" : "assist inactive:", b1, b2);
    }
}

int main() {
    compare_measurement();
    compare_straightness();
    compare_slow_tapper();
    compare_alternation();
    compare_hold_handover();
    compare_cost();
    return 0;
}
