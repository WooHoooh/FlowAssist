// Host-side tests for src/TickDrive.hpp (tick rhythm + Go Straight leveler) and src/TickDriver.hpp.
//
// The leveler is tested against SIMULATED plants (ship, wave, UFO, swing) written for this file. They are simple
// physics models, not Geometry Dash itself, so the numbers below show how the control law behaves on those
// models; they do not prove the same numbers in the game. What they do prove: the law is deterministic, never
// clicks faster than its limit, recovers from teleports and gravity flips, reproduces the Alternate Assist /
// Voidius law exactly in Classic mode, and measures better than that law on every model family tried.
//
// Build & run:  g++ -std=c++20 -O2 -Wall -Wextra -I src tests/straight_test.cpp -o straight_test && ./straight_test

#include "../src/TickDriver.hpp"
#include "baseline/AlternateLeveler.hpp"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <vector>

using namespace fa;

static int g_checks = 0;
static int g_failed = 0;

#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_failed;                                                             \
            std::printf("  FAIL line %d: %s\n       ", __LINE__, #cond);            \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

// ------------------------------------------------------------------------------------------------------------
// Plants. Units are game units and ticks, like the real controller sees them.
// ------------------------------------------------------------------------------------------------------------

struct Model {
    Fly mode;
    double aH = 0, aR = 0;   // ship: acceleration while held (up) / released (down)
    double vmax = 2.0;       // speed clamp (the wave's constant speed)
    double vj = 0;           // UFO jump speed
    double g = 0;            // UFO / swing gravity
};

struct Plant {
    Model m;
    double y = 300.0, v = 0.0, up = 1.0;
    bool held = false;
    bool gravUp = false;   // swing: gravity currently pulls up

    void press(bool down) {
        if (m.mode == Fly::Ufo) {
            if (down && !held) v = m.vj * up;
        } else if (m.mode == Fly::Swing) {
            if (down && !held) gravUp = !gravUp;
        }
        held = down;
    }
    void step() {
        switch (m.mode) {
            case Fly::Ship:
                v += up * (held ? m.aH : -m.aR);
                v = std::clamp(v, -m.vmax, m.vmax);
                break;
            case Fly::Wave: v = up * (held ? m.vmax : -m.vmax); break;
            case Fly::Ufo:
                v -= up * m.g;
                v = std::clamp(v, -6.0, 6.0);
                break;
            case Fly::Swing:
                v += gravUp ? m.g : -m.g;
                v = std::clamp(v, -m.vmax, m.vmax);
                break;
            default: break;
        }
        y += v;
    }
};

// A controller under test: answers +1 / -1 / 0 each tick.
struct Ctl {
    virtual ~Ctl() = default;
    virtual void begin(double y) = 0;
    virtual int step(double y, double up, int half, int gap) = 0;
};

struct BaselineCtl : Ctl {
    Fly mode;
    aa::Leveler L;
    bool* down;
    BaselineCtl(Fly m, bool* d) : mode(m), down(d) {}
    void begin(double y) override { L.start(y); L.change(true); }
    int step(double y, double up, int half, int gap) override {
        L.held = *down;   // exactly what Alternate Assist's main.cpp does before every call
        switch (mode) {
            case Fly::Ship: return L.stepHold(y, up, 10.0, half);
            case Fly::Wave: return L.stepHold(y, up, 1.0, half);
            case Fly::Ufo: return L.stepTap(y, up, 12.0, gap);
            default: return L.stepFlip(y, 2.0, gap);
        }
    }
};

struct NewCtl : Ctl {
    Fly mode;
    Leveler L;
    NewCtl(Fly m, StraightLaw law) : mode(m), L(law) {}
    void begin(double y) override { L.start(y, true); }
    int step(double y, double up, int half, int gap) override {
        switch (mode) {
            case Fly::Ship: return L.stepShip(y, up, half);
            case Fly::Wave: return L.stepWave(y, up, half);
            case Fly::Ufo: return L.stepUfo(y, up, gap);
            default: return L.stepSwing(y, gap);
        }
    }
};

struct Run {
    double p2p = 0, maxDev = 0, rms = 0, cps = 0;
    std::uint64_t hash = 1469598103934665603ull;
    std::vector<signed char> actions;
    bool finite = true;
};

struct Hooks {
    int flipUpAt = -1;       // tick at which gravity flips (up -> -up)
    int teleportAt = -1;     // tick at which the plant is moved
    double teleportBy = 0;
};

static Run simulate(Model const& m, double cap, double v0, Ctl& ctl, bool* downRef, Hooks const& h = {},
                    int ticks = 2400, int settle = 600) {
    Plant p;
    p.m = m;
    p.v = v0;
    p.held = true;
    if (m.mode == Fly::Ufo) p.v = m.vj;
    if (m.mode == Fly::Swing) p.gravUp = v0 > 0;
    *downRef = true;
    const double period = kTps / cap;
    const int half = std::max(1, static_cast<int>(std::lround(period / 2.0)));
    const int gap = std::max(2, static_cast<int>(std::lround(period)));
    ctl.begin(p.y);

    Run r;
    double target = p.y, mn = 1e18, mx = -1e18, ss = 0;
    int n = 0, presses = 0;
    bool prev = true;
    for (int t = 0; t < ticks; ++t) {
        if (t == h.flipUpAt) p.up = -p.up;
        if (t == h.teleportAt) { p.y += h.teleportBy; target = p.y; mn = 1e18; mx = -1e18; ss = 0; n = 0; }
        const int a = ctl.step(p.y, p.up, half, gap);
        if (a > 0) p.press(true);
        else if (a < 0) p.press(false);
        *downRef = p.held;
        if (p.held && !prev) ++presses;
        prev = p.held;
        r.actions.push_back(static_cast<signed char>(a));
        r.hash = (r.hash ^ static_cast<std::uint64_t>(a + 2)) * 1099511628211ull;
        p.step();
        if (!std::isfinite(p.y) || !std::isfinite(p.v)) r.finite = false;
        const bool measure = h.teleportAt < 0 ? t >= settle : t >= h.teleportAt + settle;
        if (measure) {
            mn = std::min(mn, p.y);
            mx = std::max(mx, p.y);
            ss += (p.y - target) * (p.y - target);
            r.maxDev = std::max(r.maxDev, std::fabs(p.y - target));
            ++n;
        }
    }
    r.p2p = n ? mx - mn : 0;
    r.rms = n ? std::sqrt(ss / n) : 0;
    r.cps = presses / (ticks / kTps);
    return r;
}

struct Case {
    Model m;
    double cap;
};

static std::vector<Case> sweep(Fly mode) {
    std::vector<Case> c;
    switch (mode) {
        case Fly::Ship:
            for (double aH : {0.02, 0.04, 0.08, 0.2, 0.4})
                for (double ratio : {0.7, 1.0, 1.4})
                    for (double cap : {12.0, 20.0, 30.0}) {
                        Model m{Fly::Ship, aH, aH * ratio, std::max(2.0, aH * 40), 0, 0};
                        c.push_back({m, cap});
                    }
            break;
        case Fly::Wave:
            for (double sl : {1.3, 2.6})
                for (double cap : {10.0, 15.0, 30.0}) c.push_back({Model{Fly::Wave, 0, 0, sl, 0, 0}, cap});
            break;
        case Fly::Ufo:
            for (double vj : {2.0, 3.0})
                for (double g : {0.06, 0.12})
                    for (double cap : {8.0, 12.0, 20.0}) c.push_back({Model{Fly::Ufo, 0, 0, 6.0, vj, g}, cap});
            break;
        default:
            for (double g : {0.04, 0.08})
                for (double cap : {8.0, 12.0, 20.0}) c.push_back({Model{Fly::Swing, 0, 0, 3.0, 0, g}, cap});
            break;
    }
    return c;
}

static Run runBase(Case const& c, double v0, Hooks const& h = {}) {
    bool down = true;
    BaselineCtl ctl(c.m.mode, &down);
    return simulate(c.m, c.cap, v0, ctl, &down, h);
}
static Run runNew(Case const& c, StraightLaw law, double v0, Hooks const& h = {}) {
    bool down = true;
    NewCtl ctl(c.m.mode, law);
    return simulate(c.m, c.cap, v0, ctl, &down, h);
}

// ------------------------------------------------------------------------------------------------------------
// TickRhythm
// ------------------------------------------------------------------------------------------------------------

static void test_tick_rhythm() {
    std::printf("[tick rhythm]\n");
    for (double cps : {5.0, 8.0, 12.0, 14.0, 20.0, 30.0, 60.0}) {
        const double period = kTps / cps;
        TickRhythm r;
        r.begin(0, period, 0.4);
        std::vector<int> pressAt;
        std::vector<int> relAt;
        pressAt.push_back(0);
        bool down = true;
        bool ok = true;
        for (std::uint32_t t = 1; t < 2400; ++t) {
            const int a = r.step(t, period, 0.4);
            if (a > 0) { ok = ok && !down; down = true; pressAt.push_back(static_cast<int>(t)); }
            if (a < 0) { ok = ok && down; down = false; relAt.push_back(static_cast<int>(t)); }
        }
        CHECK(ok, "cps %.0f: press while down or release while up", cps);
        double maxErr = 0, shortest = 1e9;
        for (std::size_t i = 1; i < pressAt.size(); ++i) {
            maxErr = std::max(maxErr, std::fabs((pressAt[i] - pressAt[0]) - i * period));
            shortest = std::min<double>(shortest, pressAt[i] - pressAt[i - 1]);
        }
        const double rate = (pressAt.size() - 1) / (pressAt.back() / kTps);
        CHECK(std::fabs(rate - cps) < 0.01 * cps + 0.05, "cps %.0f produced %.3f", cps, rate);
        CHECK(maxErr <= 1.0 + 1e-9, "cps %.0f: press %.2f ticks from its ideal slot", cps, maxErr);
        CHECK(shortest >= 2, "cps %.0f: clicks closer than 2 ticks (%.0f)", cps, shortest);
        std::size_t k = std::min(pressAt.size(), relAt.size());
        bool everyPressReleased = true;
        for (std::size_t i = 0; i < k; ++i) everyPressReleased = everyPressReleased && relAt[i] > pressAt[i];
        CHECK(everyPressReleased, "cps %.0f: a release did not follow its press", cps);
    }
    {   // starting with the button up presses on the first step
        TickRhythm r;
        r.begin(100, 20.0, 0.4, false);
        CHECK(r.step(100, 20.0, 0.4) == 1, "button-up start should press at once");
    }
    {   // a lag spike must not be answered with a burst of catch-up clicks
        TickRhythm r;
        r.begin(0, 20.0, 0.4);
        int presses = 0;
        for (std::uint32_t t = 1; t < 200; ++t) (void)r.step(t, 20.0, 0.4);
        for (std::uint32_t t = 200; t < 205; ++t) presses += r.step(t, 20.0, 0.4) > 0;
        CHECK(presses <= 1, "burst of %d presses after a jump in time", presses);
    }
}

// ------------------------------------------------------------------------------------------------------------
// Leveler vs the Alternate Assist / Voidius law
// ------------------------------------------------------------------------------------------------------------

static const char* nameOf(Fly f) {
    return f == Fly::Ship ? "ship" : f == Fly::Wave ? "wave" : f == Fly::Ufo ? "ufo" : "swing";
}

static void test_classic_matches_voidius() {
    std::printf("[classic law == Alternate Assist / Voidius law]\n");
    for (Fly f : {Fly::Ship, Fly::Wave, Fly::Ufo, Fly::Swing}) {
        int cases = 0, same = 0;
        for (auto const& c : sweep(f))
            for (double v0 : {0.0, 0.8}) {
                const Run b = runBase(c, v0);
                const Run n = runNew(c, StraightLaw::Classic, v0);
                ++cases;
                same += b.hash == n.hash && b.actions == n.actions;
            }
        CHECK(same == cases, "%s: Classic differs from the baseline in %d of %d runs", nameOf(f), cases - same, cases);
        std::printf("  %-5s %d/%d runs identical action-for-action\n", nameOf(f), same, cases);
    }
}

struct Agg {
    double p2p = 0, dev = 0, worstDev = 0;
    int n = 0;
    void add(Run const& r) { p2p += r.p2p; dev += r.maxDev; worstDev = std::max(worstDev, r.maxDev); ++n; }
    double mp() const { return p2p / n; }
    double md() const { return dev / n; }
};

static void test_predictive_vs_baseline() {
    std::printf("[predictive law vs baseline, simulated plants]\n");
    for (Fly f : {Fly::Ship, Fly::Wave, Fly::Ufo, Fly::Swing}) {
        Agg base, pred;
        bool finite = true;
        double worstCps = 0;
        for (auto const& c : sweep(f))
            for (double v0 : {0.0, 0.8}) {
                const Run b = runBase(c, v0);
                const Run p = runNew(c, StraightLaw::Predictive, v0);
                base.add(b);
                pred.add(p);
                finite = finite && p.finite;
                worstCps = std::max(worstCps, p.cps / c.cap);
            }
        std::printf("  %-5s runs=%2d  peak-to-peak %8.2f -> %8.2f   worst distance from level %8.2f -> %8.2f (mean %7.2f -> %7.2f)\n",
                    nameOf(f), pred.n, base.mp(), pred.mp(), base.worstDev, pred.worstDev, base.md(), pred.md());
        CHECK(finite, "%s: non-finite plant state", nameOf(f));
        CHECK(worstCps <= 1.02, "%s: clicked %.1f%% of the CPS limit", nameOf(f), worstCps * 100);
        switch (f) {
            case Fly::Ship:
                CHECK(pred.mp() <= 0.95 * base.mp(), "ship p2p not better: %.2f vs %.2f", pred.mp(), base.mp());
                CHECK(pred.md() <= 0.85 * base.md(), "ship distance not better: %.2f vs %.2f", pred.md(), base.md());
                break;
            case Fly::Wave:   // limited only by the shortest leg the CPS limit allows: must not be worse
                CHECK(pred.mp() <= base.mp() + 1e-9 && pred.md() <= base.md() + 1e-9, "wave got worse");
                break;
            case Fly::Ufo:    // one jump arc is the physical minimum for peak-to-peak; the arc is now centred
                CHECK(pred.mp() <= 1.05 * base.mp(), "ufo p2p worse: %.2f vs %.2f", pred.mp(), base.mp());
                CHECK(pred.md() <= 0.5 * base.md(), "ufo distance not better: %.2f vs %.2f", pred.md(), base.md());
                break;
            default:
                CHECK(pred.worstDev < 120.0, "swing wandered %.1f units from level", pred.worstDev);
                CHECK(pred.md() <= 0.1 * base.md(), "swing distance not better: %.2f vs %.2f", pred.md(), base.md());
                break;
        }
    }
}

static void test_wave_is_at_its_floor() {
    std::printf("[wave: as straight as its CPS limit allows]\n");
    for (auto const& c : sweep(Fly::Wave)) {
        const Run r = runNew(c, StraightLaw::Predictive, 0.0);
        const int half = std::max(1, static_cast<int>(std::lround(kTps / c.cap / 2.0)));
        const double floor = c.m.vmax * half;   // one leg of `half` ticks at the wave's speed
        CHECK(r.p2p <= floor + 1e-9, "cap %.0f speed %.1f: p2p %.2f above the one-leg floor %.2f", c.cap, c.m.vmax, r.p2p, floor);
    }
}

static void test_determinism_and_limits() {
    std::printf("[determinism, click limit, extreme limits]\n");
    for (Fly f : {Fly::Ship, Fly::Wave, Fly::Ufo, Fly::Swing})
        for (auto const& c : sweep(f)) {
            const Run a = runNew(c, StraightLaw::Predictive, 0.5);
            const Run b = runNew(c, StraightLaw::Predictive, 0.5);
            CHECK(a.hash == b.hash && a.actions == b.actions, "%s: two identical runs differ", nameOf(f));
        }
    for (Fly f : {Fly::Ship, Fly::Wave, Fly::Ufo, Fly::Swing})
        for (double cap : {2.0, 60.0}) {
            Model m = sweep(f).front().m;
            const Run r = runNew({m, cap}, StraightLaw::Predictive, 0.0);
            CHECK(r.finite, "%s cap %.0f: non-finite", nameOf(f), cap);
            CHECK(r.cps <= cap * 1.02 + 0.3, "%s cap %.0f: %.2f clicks/s", nameOf(f), cap, r.cps);
        }
}

static void test_fallbacks() {
    std::printf("[fallback to the classic law]\n");
    // Until it has measured the plant, the predictive law must answer exactly like Classic.
    const Case c = sweep(Fly::Ship)[4];
    bool down = true, down2 = true;
    NewCtl classic(Fly::Ship, StraightLaw::Classic), pred(Fly::Ship, StraightLaw::Predictive);
    Plant p1, p2;
    p1.m = p2.m = c.m;
    p1.held = p2.held = true;
    classic.begin(p1.y);
    pred.begin(p2.y);
    const double period = kTps / c.cap;
    const int half = std::max(1, static_cast<int>(std::lround(period / 2.0)));
    int firstDiff = -1, learnedAt = -1;
    for (int t = 0; t < 600; ++t) {
        const int a = classic.step(p1.y, 1.0, half, 2 * half);
        const int b = pred.step(p2.y, 1.0, half, 2 * half);
        if (learnedAt < 0 && pred.L.learned(Fly::Ship)) learnedAt = t;
        if (a != b && firstDiff < 0) firstDiff = t;
        if (a) p1.press(a > 0);
        if (b) p2.press(b > 0);
        down = p1.held;
        down2 = p2.held;
        p1.step();
        p2.step();
    }
    (void)down; (void)down2;
    CHECK(learnedAt > 0, "never learned the ship");
    CHECK(firstDiff < 0 || firstDiff >= learnedAt, "diverged at tick %d before learning (%d)", firstDiff, learnedAt);

    // A plant that pushes 20x harder one way than the other is not believable: stay on the classic law.
    Model odd{Fly::Ship, 0.4, 0.02, 4.0, 0, 0};
    const Run a = runNew({odd, 20.0}, StraightLaw::Classic, 0.0);
    const Run b = runNew({odd, 20.0}, StraightLaw::Predictive, 0.0);
    CHECK(a.actions == b.actions, "implausible plant: predictive did not fall back to classic");
}

static void test_teleport_and_gravity_flip() {
    std::printf("[teleport / gravity flip recovery]\n");
    Case c{Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0}, 20.0};
    const Run settled = runNew(c, StraightLaw::Predictive, 0.0);
    {
        Hooks h;
        h.teleportAt = 1200;
        h.teleportBy = 500.0;
        const Run r = runNew(c, StraightLaw::Predictive, 0.0, h);
        CHECK(r.maxDev <= 3.0 * settled.maxDev + 1.0, "after a 500-unit teleport: %.2f from the new level (settled %.2f)", r.maxDev, settled.maxDev);
    }
    {
        Hooks h;
        h.flipUpAt = 1200;
        h.teleportAt = 1200;   // measure from the flip on, around the height it was at
        h.teleportBy = 0.0;
        const Run r = runNew(c, StraightLaw::Predictive, 0.0, h);
        CHECK(r.finite && r.maxDev <= 4.0 * settled.maxDev + 2.0, "after a gravity flip: %.2f from level (settled %.2f)", r.maxDev, settled.maxDev);
    }
}

// ------------------------------------------------------------------------------------------------------------
// TickDriver + Engine in a small game loop
// ------------------------------------------------------------------------------------------------------------

struct World {
    Engine eng;
    TickDriver drv;
    StraightConfig sc;
    Plant plant;
    PlayerView view{Fly::Ship, 300.0, 1.0};
    bool gameDown = false;
    int violations = 0;                     // the game saw a press while down / a release while up
    std::vector<int> pressTicks;            // ticks at which the game button went down
    int ownTickActions = 0;                 // actions the engine produced itself (must stay 0 with external drive)
    double fps = 60.0;
    bool finger = false;
    int tickNow = 0;                        // run() continues from here
    double nextFrame = 0.0;
    std::size_t ei = 0;

    explicit World(bool external) { eng.setExternalDrive(external); }

    void emit(int tick, bool down) {
        if (down == gameDown) ++violations;
        gameDown = down;
        if (down) pressTicks.push_back(tick);
        plant.press(down);
    }

    // Runs `ticks` more ticks (240 per second) of the game loop. Frames come at `fps`; real events are given as
    // {absolute tick, down} and are consumed in order across calls.
    void run(int ticks, std::vector<std::pair<int, bool>> const& events) {
        const int end = tickNow + ticks;
        for (; tickNow < end; ++tickNow) {
            const int t = tickNow;
            const double now = t / kTps;
            if (t >= nextFrame) {
                nextFrame += kTps / fps;
                const auto out = eng.tick(now);
                if (out.action != Action::None) {
                    ++ownTickActions;
                    emit(t, out.action == Action::Press);
                }
            }
            while (ei < events.size() && events[ei].first <= t) {
                const bool down = events[ei].second;
                finger = down;
                if (down) {
                    const auto r = eng.onRealPress(now, true);
                    if (r.preRelease) emit(t, false);
                    if (r.forward) emit(t, true);
                } else {
                    const auto r = eng.onRealRelease(now, true);
                    if (r.forward) emit(t, false);
                }
                ++ei;
            }
            if (eng.externalDrive()) {
                view.y = plant.y;
                view.up = plant.up;
                const int a = drv.step(eng, sc, static_cast<std::uint32_t>(t), view);
                if (a != 0) emit(t, a > 0);
            }
            plant.step();
        }
    }
};

static std::vector<std::pair<int, bool>> spam(double cps, double startSec, double seconds, double holdFrac = 0.4) {
    std::vector<std::pair<int, bool>> ev;
    const double period = 1.0 / cps;
    for (double t = startSec; t < startSec + seconds; t += period) {
        ev.push_back({static_cast<int>(t * kTps), true});
        ev.push_back({static_cast<int>((t + holdFrac * period) * kTps), false});
    }
    return ev;
}

static void test_driver_with_engine() {
    std::printf("[driver + engine in a game loop]\n");
    {   // ship: activation, level flight, hand-back when the player stops
        World w(true);
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 2.0);
        w.run(static_cast<int>(4.0 * kTps), ev);
        CHECK(w.ownTickActions <= 1, "engine produced %d actions of its own with external drive on", w.ownTickActions);
        CHECK(w.violations == 0, "game saw %d double presses / releases", w.violations);
        CHECK(!w.gameDown, "button stuck down after the player stopped");
        CHECK(!w.eng.active(), "assist still active 1.8 s after the player stopped");
        CHECK(w.pressTicks.size() > 20, "assist produced only %zu presses", w.pressTicks.size());
    }
    {   // the snapshot reports straight flight while it lasts
        World w(true);
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 3.0);
        w.run(static_cast<int>(1.5 * kTps), ev);
        const auto snap = w.eng.snapshot(1.5);
        CHECK(snap.active && snap.straight, "snapshot active=%d straight=%d", snap.active, snap.straight);
        CHECK(snap.assisted > 5, "assisted counter %u", snap.assisted);
        CHECK(w.drv.straight() && w.drv.running(), "driver not running straight");
    }
    {   // Go Straight off: plain rhythm, not straight, at the engine's own rate
        World w(true);
        w.sc.enabled = false;
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 3.0);
        w.run(static_cast<int>(3.0 * kTps), ev);
        const auto snap = w.eng.snapshot(3.0);
        CHECK(snap.active && !snap.straight, "snapshot active=%d straight=%d", snap.active, snap.straight);
        CHECK(w.violations == 0, "violations %d", w.violations);
    }
    {   // cube: plain rhythm, no leveler involved
        World w(true);
        w.view.mode = Fly::None;
        auto ev = spam(14.0, 0.2, 3.0);
        w.run(static_cast<int>(3.4 * kTps), ev);
        CHECK(w.violations == 0 && w.ownTickActions <= 1, "violations %d own %d", w.violations, w.ownTickActions);
        CHECK(!w.drv.straight(), "cube must not use the leveler");
    }
    {   // holding the button hands it back to the player and keeps it down
        World w(true);
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 1.0);
        ev.push_back({static_cast<int>(1.3 * kTps), true});   // press and keep holding
        w.run(static_cast<int>(2.5 * kTps), ev);
        CHECK(!w.eng.active(), "assist still active while the player holds");
        CHECK(w.gameDown, "player is holding but the game button is up");
        CHECK(w.violations == 0, "violations %d", w.violations);
    }
    {   // gamemode changes in the middle of the assist: no stuck button, no double events, keeps clicking
        World w(true);
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 3.0);
        w.run(static_cast<int>(2 * kTps), ev);
        const std::size_t before = w.pressTicks.size();
        w.view.mode = Fly::Wave;                 // portal: ship -> wave
        w.plant.m = Model{Fly::Wave, 0, 0, 1.3, 0, 0};
        w.run(static_cast<int>(1.0 * kTps), ev);
        CHECK(w.pressTicks.size() > before + 3, "stopped clicking after the gamemode change");
        w.view.mode = Fly::None;                 // wave -> cube: plain rhythm
        w.run(static_cast<int>(0.4 * kTps), ev);
        w.run(static_cast<int>(2.5 * kTps), ev); // the player stops spamming at 3.2 s
        CHECK(w.violations == 0, "violations %d across gamemode changes", w.violations);
        CHECK(!w.gameDown && !w.eng.active(), "button stuck or assist still on after the player stopped");
    }
    {   // restart mid-assist: reset releases an assist-held button and the driver starts clean
        World w(true);
        w.plant.m = Model{Fly::Ship, 0.04, 0.04, 2.0, 0, 0};
        auto ev = spam(14.0, 0.2, 3.0);
        w.run(static_cast<int>(1.5 * kTps), ev);
        const auto r = w.eng.reset();
        if (r.action == Action::Release) w.emit(w.tickNow, false);
        w.drv.reset();
        CHECK(!w.gameDown, "button down after reset");
        CHECK(!w.eng.active(), "engine active after reset");
        CHECK(w.violations == 0, "violations %d", w.violations);
    }
}

// Timing accuracy of the plain rhythm: the v1.1.0 frame-aware output vs the tick grid.
static void test_timing_accuracy() {
    std::printf("[plain rhythm timing: frame-aware (v1.1.0) vs tick grid]\n");
    for (double fps : {60.0, 144.0}) {
        for (double cps : {12.0, 14.0, 17.0}) {
            double err[2] = {0, 0};
            for (int mode = 0; mode < 2; ++mode) {
                World w(mode == 1);
                w.fps = fps;
                w.view.mode = Fly::None;
                Config c;
                c.activationCps = 8.0;
                c.targetCps = cps;
                c.strength = 1.0;
                w.eng.setConfig(c);
                auto ev = spam(cps + 2.0, 0.2, 5.0);
                w.run(static_cast<int>(6.0 * kTps), ev);
                // look at assisted presses only: skip the ones the player made before the takeover
                std::vector<int> pr = w.pressTicks;
                if (pr.size() < 20) { CHECK(false, "too few presses (%zu)", pr.size()); continue; }
                const double period = kTps / cps;
                double e = 0;
                for (std::size_t i = 10; i + 1 < pr.size() - 4; ++i) {
                    const double gap = pr[i + 1] - pr[i];
                    e = std::max(e, std::fabs(gap - period));
                }
                err[mode] = e;
            }
            std::printf("  %3.0f fps, %2.0f cps: worst click-to-click error  frame-aware %.2f ticks (%.1f ms)  tick grid %.2f ticks (%.1f ms)\n",
                        fps, cps, err[0], err[0] * 1000 / kTps, err[1], err[1] * 1000 / kTps);
            CHECK(err[1] <= err[0] + 1e-9, "tick grid is not at least as accurate (%.2f vs %.2f)", err[1], err[0]);
            CHECK(err[1] <= 1.0 + 1e-9, "tick grid error %.2f ticks", err[1]);
        }
    }
}

int main() {
    test_tick_rhythm();
    test_classic_matches_voidius();
    test_predictive_vs_baseline();
    test_wave_is_at_its_floor();
    test_determinism_and_limits();
    test_fallbacks();
    test_teleport_and_gravity_flip();
    test_driver_with_engine();
    test_timing_accuracy();
    std::printf("\n%d checks, %d failed\n", g_checks, g_failed);
    return g_failed == 0 ? 0 : 1;
}
