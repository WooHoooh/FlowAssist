// Host-side tests for src/AssistEngine.hpp (Flow Assist engine).
//
// These exercise the rhythm logic only (CPS measurement, activation, assistance, stop
// conditions, input arbitration). They say NOTHING about the Geode hooks, the UI, or how
// either target platform behaves - those need a real GD + Geode install.
//
// Build & run:  g++ -std=c++20 -O2 -Wall -Wextra -I src tests/engine_test.cpp -o engine_test && ./engine_test

#include "../src/AssistEngine.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <functional>
#include <random>
#include <vector>

using namespace fa;

static int g_checks = 0;
static int g_failed = 0;

#define CHECK(cond, ...)                                                            \
    do {                                                                            \
        ++g_checks;                                                                 \
        if (!(cond)) {                                                              \
            ++g_failed;                                                             \
            std::printf("  FAIL line %d: %s\n       ", __LINE__, #cond);            \
            std::printf(__VA_ARGS__);                                               \
            std::printf("\n");                                                      \
        }                                                                           \
    } while (0)

// ------------------------------------------------------------------------------------------
// Simulation harness: feeds real events + per-frame ticks to an Engine and records exactly what
// the *game* would see (forwarded real events + synthetic ones).
// ------------------------------------------------------------------------------------------

struct GameEv {
    double t;
    bool down;
    bool injected;
};

struct Sim {
    Engine eng;
    std::vector<GameEv> game;
    bool gameDown = false;
    int violations = 0;     // game saw a press while down, or a release while up
    int fingers = 0;        // physical state
    double fingerSince = -1;  // time the finger last went down (event level), -1 when up
    int activations = 0;
    int deactivations = 0;

    void emit(double t, bool down, bool injected) {
        if (down == gameDown) ++violations;
        gameDown = down;
        game.push_back({t, down, injected});
    }
    void press(double t, bool p1 = true) {
        if (fingers == 0) fingerSince = t;
        ++fingers;
        const auto r = eng.onRealPress(t, p1);
        if (r.activated) ++activations;
        if (r.preRelease) emit(t, false, true);
        if (r.forward) emit(t, true, false);
    }
    void release(double t, bool p1 = true) {
        if (fingers > 0) --fingers;
        if (fingers == 0) fingerSince = -1;
        const auto r = eng.onRealRelease(t, p1);
        if (r.forward) emit(t, false, false);
    }
    TickResult tick(double t) {
        const auto o = eng.tick(t);
        if (o.deactivated) ++deactivations;
        if (o.action == Action::Press) emit(t, true, true);
        else if (o.action == Action::Release) emit(t, false, true);
        return o;
    }
};

struct RealEv {
    double t;
    bool press;
    bool p1;
};

// Real events are delivered on the first frame at/after their time, stamped with that frame's time
// (the game dispatches input once per frame), unless quantize == false.
static void play(Sim& s, std::vector<RealEv> const& evs, double fps, double tEnd, bool quantize = true,
                 std::function<void(double)> afterTick = {}) {
    size_t i = 0;
    const double dt = 1.0 / fps;
    for (long k = 0;; ++k) {
        const double f = static_cast<double>(k) * dt;
        if (f > tEnd) break;
        while (i < evs.size() && evs[i].t <= f + 1e-12) {
            const double te = quantize ? f : evs[i].t;
            if (evs[i].press) s.press(te, evs[i].p1);
            else s.release(te, evs[i].p1);
            ++i;
        }
        s.tick(f);
        if (afterTick) afterTick(f);
    }
}

// A train of taps. Returns events sorted by time (single finger, well formed).
static std::vector<RealEv> train(double start, double rate, int n, double tap, double jitter, std::mt19937& rng,
                                 bool p1 = true) {
    std::vector<RealEv> v;
    std::uniform_real_distribution<double> u(-1.0, 1.0);
    double t = start;
    for (int i = 0; i < n; ++i) {
        const double interval = (1.0 / rate) * (1.0 + (jitter > 0 ? jitter * u(rng) : 0.0));
        const double d = std::min(tap, 0.7 * interval);
        v.push_back({t, true, p1});
        v.push_back({t + d, false, p1});
        t += interval;
    }
    return v;
}

static std::vector<double> pressTimes(Sim const& s, double from, double to) {
    std::vector<double> v;
    for (auto const& e : s.game)
        if (e.down && e.t >= from && e.t < to) v.push_back(e.t);
    return v;
}

static double cv(std::vector<double> const& times) {
    if (times.size() < 4) return 1e9;
    std::vector<double> d;
    for (size_t i = 1; i < times.size(); ++i) d.push_back(times[i] - times[i - 1]);
    double mean = 0;
    for (double x : d) mean += x;
    mean /= static_cast<double>(d.size());
    double var = 0;
    for (double x : d) var += (x - mean) * (x - mean);
    var /= static_cast<double>(d.size());
    return std::sqrt(var) / mean;
}

// ------------------------------------------------------------------------------------------
// 1. CPS detection accuracy
// ------------------------------------------------------------------------------------------

static void test_cps_accuracy() {
    std::printf("[1] CPS detection accuracy\n");
    Config off;
    off.enabled = false;  // measurement only

    std::printf("    steady trains, exact timestamps (worst error after the 5th click):\n");
    for (double rate : {2.0, 3.0, 4.0, 5.0, 6.0, 8.0, 10.0, 12.0, 15.0, 20.0, 25.0, 30.0, 40.0}) {
        Engine e;
        e.setConfig(off);
        double worst = 0;
        for (int i = 0; i < 60; ++i) {
            const double t = 0.5 + i / rate;
            e.onRealPress(t, true);
            e.onRealRelease(t + 0.015);
            if (i >= 4) worst = std::max(worst, std::fabs(e.cps(t) - rate) / rate);
        }
        std::printf("      %5.1f CPS -> worst error %5.2f%%\n", rate, worst * 100.0);
        CHECK(worst < 0.03, "rate %.1f worst error %.4f", rate, worst);
    }

    std::printf("    steady trains, timestamps quantised to 60 FPS frames:\n");
    for (double rate : {4.0, 6.0, 8.0, 10.0, 12.0, 15.0, 20.0, 25.0, 30.0}) {
        Engine e;
        e.setConfig(off);
        double worst = 0;
        const double dt = 1.0 / 60.0;
        for (int i = 0; i < 60; ++i) {
            const double t = std::ceil((0.5 + i / rate) / dt) * dt;
            e.onRealPress(t, true);
            if (i >= 8) worst = std::max(worst, std::fabs(e.cps(t) - rate) / rate);
        }
        std::printf("      %5.1f CPS -> worst error %5.2f%%\n", rate, worst * 100.0);
        CHECK(worst < 0.06, "60fps rate %.1f worst error %.4f", rate, worst);
    }

    std::printf("    jittery 10 CPS train (+-25%% per interval), 40 seeds x 38 samples:\n");
    std::vector<double> errs;
    for (int seed = 0; seed < 40; ++seed) {
        std::mt19937 rng(static_cast<unsigned>(seed));
        std::uniform_real_distribution<double> u(-0.25, 0.25);
        Engine e;
        e.setConfig(off);
        double t = 0.3;
        for (int i = 0; i < 50; ++i) {
            e.onRealPress(t, true);
            e.onRealRelease(t + 0.02);
            if (i >= 12) errs.push_back(std::fabs(e.cps(t) - 10.0) / 10.0);
            t += 0.1 * (1.0 + u(rng));
        }
    }
    std::sort(errs.begin(), errs.end());
    double meanErr = 0;
    for (double x : errs) meanErr += x;
    meanErr /= static_cast<double>(errs.size());
    const double p99 = errs[errs.size() * 99 / 100];
    std::printf("      mean error %5.2f%%, 99th percentile %5.2f%%, worst %5.2f%% (vs the nominal 10 CPS; the real\n"
                "      per-interval jitter alone makes the true rate of any 1 s window differ by about +-4%%)\n",
                meanErr * 100.0, p99 * 100.0, errs.back() * 100.0);
    CHECK(meanErr < 0.05, "jitter mean error %.4f", meanErr);
    CHECK(p99 < 0.12, "jitter p99 error %.4f", p99);

    std::printf("    decay after the player stops:\n");
    {
        Engine e;
        e.setConfig(off);
        for (int i = 0; i < 12; ++i) e.onRealPress(1.0 + i * 0.1, true);
        const double last = 1.0 + 11 * 0.1;
        CHECK(std::fabs(e.cps(last) - 10.0) < 0.3, "cps at last press %.2f", e.cps(last));
        CHECK(e.cps(last + 0.25) < 4.1, "cps 0.25s later %.2f", e.cps(last + 0.25));
        CHECK(e.cps(last + 1.01) == 0.0, "cps 1s later %.2f", e.cps(last + 1.01));
        std::printf("      10.0 CPS -> %.2f after 0.25 s -> %.2f after 1 s\n", e.cps(last + 0.25), e.cps(last + 1.01));
    }
}

// ------------------------------------------------------------------------------------------
// 2. Activation threshold
// ------------------------------------------------------------------------------------------

static int activatesAtPress(double rate, double threshold) {
    Engine e;
    Config c;
    c.activationCps = threshold;
    c.targetCps = std::max(12.0, threshold + 2);
    e.setConfig(c);
    for (int i = 0; i < 60; ++i) {
        const double t = 0.2 + i / rate;
        const auto r = e.onRealPress(t, true);
        e.onRealRelease(t + 0.02);
        if (r.activated) return i + 1;
    }
    return -1;
}

static void test_activation_threshold() {
    std::printf("[2] Activation threshold\n");
    struct Case { double rate, thr; bool expect; };
    const Case cases[] = {
        {7.0, 8.0, false},  {7.7, 8.0, false}, {8.5, 8.0, true},  {9.0, 8.0, true},  {12.0, 8.0, true},
        {4.5, 5.0, false},  {5.6, 5.0, true},  {14.0, 15.0, false}, {16.0, 15.0, true},
        {3.2, 3.0, true},   {2.5, 3.0, false}, {24.0, 25.0, false}, {27.0, 25.0, true},
    };
    for (auto const& c : cases) {
        const int n = activatesAtPress(c.rate, c.thr);
        std::printf("      %5.1f CPS vs threshold %4.1f -> %s\n", c.rate, c.thr,
                    n < 0 ? "never active" : ("active at press #" + std::to_string(n)).c_str());
        CHECK((n > 0) == c.expect, "rate %.1f thr %.1f got %d", c.rate, c.thr, n);
        if (c.expect) CHECK(n >= Engine::kMinClicks && n <= Engine::kMinClicks + 2, "late activation %d", n);
    }
}

static void test_no_activation_from_lone_click() {
    std::printf("[2b] A lone click after a pause must not start the assist\n");
    Sim s;
    Config c;
    c.activationCps = 8;
    s.eng.setConfig(c);
    std::mt19937 rng(1);
    auto ev = train(0.2, 12.0, 7, 0.04, 0, rng);            // spam: activates around the 4th click
    const double stopT = ev.back().t;
    auto lone1 = train(stopT + 0.75, 5.0, 1, 0.04, 0, rng); // a single click well after the pause
    auto lone2 = train(stopT + 1.60, 5.0, 1, 0.04, 0, rng); // and another
    auto again = train(stopT + 2.40, 12.0, 6, 0.04, 0, rng);
    ev.insert(ev.end(), lone1.begin(), lone1.end());
    ev.insert(ev.end(), lone2.begin(), lone2.end());
    ev.insert(ev.end(), again.begin(), again.end());
    play(s, ev, 120, stopT + 4.0);
    std::printf("      activations: %d (expected 2: first burst, second burst)\n", s.activations);
    CHECK(s.activations == 2, "activations %d", s.activations);
    CHECK(s.violations == 0, "violations %d", s.violations);
}

// ------------------------------------------------------------------------------------------
// 3. Normal clicking is untouched when disabled / not active
// ------------------------------------------------------------------------------------------

static void test_passthrough() {
    std::printf("[3] Normal clicking when disabled / below threshold\n");
    std::mt19937 rng(7);

    for (int variant = 0; variant < 2; ++variant) {
        Sim s;
        Config c;
        c.enabled = (variant == 1);
        c.activationCps = 8;
        s.eng.setConfig(c);
        // variant 0: disabled, fast spam, holds and singles.  variant 1: enabled, but always below threshold.
        std::vector<RealEv> ev;
        double t = 0.1;
        for (int seg = 0; seg < 40; ++seg) {
            const double rate = (variant == 0) ? 6.0 + 20.0 * (rng() % 100) / 100.0 : 4.0 + 3.0 * (rng() % 100) / 100.0;
            auto tr = train(t, rate, 3 + static_cast<int>(rng() % 10), 0.03 + 0.2 * (rng() % 100) / 100.0, 0.2, rng);
            ev.insert(ev.end(), tr.begin(), tr.end());
            t = tr.back().t + 0.5 + (rng() % 100) / 100.0;
        }
        play(s, ev, 144, t + 1.0, /*quantize=*/false);
        size_t injected = 0;
        for (auto const& g : s.game) injected += g.injected ? 1 : 0;
        bool same = s.game.size() == ev.size();
        for (size_t i = 0; same && i < ev.size(); ++i)
            same = s.game[i].down == ev[i].press && !s.game[i].injected && std::fabs(s.game[i].t - ev[i].t) < 1e-9;
        std::printf("      %-34s %zu real events -> %zu game events, %zu injected, identical: %s\n",
                    variant == 0 ? "feature disabled:" : "enabled, below threshold:", ev.size(), s.game.size(), injected,
                    same ? "yes" : "NO");
        CHECK(same, "variant %d stream differs from the real one", variant);
        CHECK(injected == 0, "variant %d injected %zu", variant, injected);
        CHECK(s.activations == 0, "variant %d activations %d", variant, s.activations);
    }
}

// ------------------------------------------------------------------------------------------
// 4. Assistance behaviour: rate vs strength, rhythm consistency
// ------------------------------------------------------------------------------------------

static void test_assist_rate() {
    std::printf("[4] Assistance behaviour: output rate (player 9 CPS, activation 8, target 12)\n");
    for (double fps : {60.0, 144.0, 240.0}) {
        for (double strength : {0.0, 0.5, 1.0}) {
            std::mt19937 rng(3);
            Sim s;
            Config c;
            c.activationCps = 8;
            c.targetCps = 12;
            c.strength = strength;
            s.eng.setConfig(c);
            auto ev = train(0.2, 9.0, 40, 0.045, 0.0, rng);
            play(s, ev, fps, 4.6);
            const auto p = pressTimes(s, 1.2, 3.7);
            const double rate = static_cast<double>(p.size()) / 2.5;
            const double expected = 9.0 + strength * 3.0;
            std::printf("      %5.0f FPS  strength %3.0f%% -> %5.2f CPS out (expected %5.2f), interval CV %.3f\n", fps,
                        strength * 100, rate, expected, cv(p));
            CHECK(std::fabs(rate - expected) / expected < 0.07, "fps %.0f strength %.1f rate %.2f expected %.2f", fps,
                  strength, rate, expected);
            CHECK(s.violations == 0, "violations %d", s.violations);
        }
    }
}

static void test_rhythm_consistency() {
    std::printf("[4b] Rhythm consistency: jittery 10 CPS input (+-25%%), strength 100%%, target 12\n");
    for (double fps : {60.0, 144.0, 240.0}) {
        double inCv = 0, outCv = 0;
        const int seeds = 10;
        for (int seed = 0; seed < seeds; ++seed) {
            std::mt19937 rng(static_cast<unsigned>(100 + seed));
            Sim s;
            Config c;
            c.activationCps = 8;
            c.targetCps = 12;
            c.strength = 1.0;
            s.eng.setConfig(c);
            auto ev = train(0.2, 10.0, 60, 0.04, 0.25, rng);
            play(s, ev, fps, 6.0);
            std::vector<double> in;
            for (auto const& e : ev)
                if (e.press && e.t >= 1.2 && e.t < 5.0) in.push_back(e.t);
            inCv += cv(in);
            outCv += cv(pressTimes(s, 1.2, 5.0));
            CHECK(s.violations == 0, "violations %d", s.violations);
        }
        inCv /= seeds;
        outCv /= seeds;
        std::printf("      %5.0f FPS: click-interval CV  input %.3f -> output %.3f\n", fps, inCv, outCv);
        CHECK(outCv < inCv * 0.75, "fps %.0f output CV %.3f not better than input %.3f", fps, outCv, inCv);
    }
}

// ------------------------------------------------------------------------------------------
// 5. Stop conditions
// ------------------------------------------------------------------------------------------

static void test_stops_when_player_stops() {
    std::printf("[5] Stops when the player stops clicking\n");
    for (double fps : {60.0, 120.0, 240.0}) {
        std::mt19937 rng(11);
        Sim s;
        Config c;
        c.activationCps = 8;
        c.targetCps = 14;
        c.strength = 1.0;
        s.eng.setConfig(c);
        auto ev = train(0.2, 12.0, 30, 0.04, 0.0, rng);
        const double lastReal = ev.back().t - 0.04;  // time of the last real press
        play(s, ev, fps, lastReal + 2.0);
        double lastInjected = -1;
        for (auto const& g : s.game)
            if (g.injected && g.down) lastInjected = g.t;
        double lastEvent = s.game.empty() ? 0 : s.game.back().t;
        std::printf("      %5.0f FPS: last injected press %.0f ms after the last real press; last game event %.0f ms after; "
                    "final game state: %s\n",
                    fps, (lastInjected - lastReal) * 1000, (lastEvent - lastReal) * 1000, s.gameDown ? "STUCK DOWN" : "released");
        CHECK(lastInjected - lastReal <= 0.45, "kept clicking %.3f s after the player stopped", lastInjected - lastReal);
        CHECK(lastEvent - lastReal <= 0.62, "events %.3f s after the player stopped", lastEvent - lastReal);
        CHECK(!s.gameDown, "game button stuck down");
        CHECK(!s.eng.active(), "still active");
        CHECK(s.violations == 0, "violations %d", s.violations);
    }
}

static void test_slows_down() {
    std::printf("[5b] Stops when the player falls below the configured conditions (slows down)\n");
    Sim s;
    Config c;
    c.activationCps = 8;
    c.targetCps = 12;
    c.strength = 0.5;
    s.eng.setConfig(c);
    std::mt19937 rng(5);
    auto ev = train(0.2, 11.0, 22, 0.04, 0.0, rng);               // 2 s of fast spam: active
    auto slow = train(ev.back().t + 0.09, 4.0, 12, 0.05, 0.0, rng);  // then 4 CPS clicking
    ev.insert(ev.end(), slow.begin(), slow.end());
    bool activeAtEndOfSpam = false;
    play(s, ev, 120, 5.5, true, [&](double f) {
        if (std::fabs(f - 2.0) < 1.0 / 240) activeAtEndOfSpam = s.eng.active();
    });
    std::printf("      active during spam: %s; active at end: %s; deactivations: %d\n", activeAtEndOfSpam ? "yes" : "no",
                s.eng.active() ? "yes" : "no", s.deactivations);
    CHECK(activeAtEndOfSpam, "was not active during spam");
    CHECK(!s.eng.active(), "still active after slowing to 4 CPS");
    // After the slow-down the slow clicks must reach the game as the player made them.
    size_t realSlowPresses = 0, gameSlowPresses = 0;
    for (auto const& e : slow) realSlowPresses += e.press ? 1 : 0;
    for (auto const& g : s.game)
        if (g.down && g.t > slow.front().t + 1.0) ++gameSlowPresses;
    CHECK(gameSlowPresses + 4 >= realSlowPresses - 4, "slow clicks dropped: %zu of %zu", gameSlowPresses, realSlowPresses);
    CHECK(s.violations == 0, "violations %d", s.violations);
}

static void test_hold_handover() {
    std::printf("[5c] Holding the button hands it back (worst case: the assist's own release lands just before the hold is noticed)\n");
    double worstGapAll = 0;
    for (int variant = 0; variant < 12; ++variant) {
        std::mt19937 rng(21 + variant);
        Sim s;
        Config c;
        c.activationCps = 8;
        c.targetCps = 13;
        c.strength = 1.0;
        c.holdBreak = 0.10;
        s.eng.setConfig(c);
        auto ev = train(0.2, 11.0, 20, 0.04, 0.0, rng);
        // start the hold at a different phase of the assist's rhythm each time
        const double holdAt = ev.back().t + 0.05 + 0.007 * variant;
        ev.push_back({holdAt, true, true});
        ev.push_back({holdAt + 0.5, false, true});
        const double fps = 240;
        bool downAfterBreak = true;
        double gap = 0;  // time the game saw "up" while the finger was down
        double prevF = -1;
        play(s, ev, fps, holdAt + 1.2, true, [&](double f) {
            if (f >= holdAt && f < holdAt + 0.5 && !s.gameDown && prevF >= 0) gap += f - prevF;
            if (f >= holdAt + 0.10 + 3.0 / fps && f < holdAt + 0.5 - 0.01 && !s.gameDown) downAfterBreak = false;
            prevF = f;
        });
        worstGapAll = std::max(worstGapAll, gap);
        if (variant < 4 || variant == 11)
            std::printf("      variant %2d: game up for %3.0f ms of the hold before it was noticed; down for the rest: %s; released at the end: %s\n",
                        variant, gap * 1000, downAfterBreak ? "yes" : "NO", s.gameDown ? "NO" : "yes");
        CHECK(downAfterBreak, "variant %d: hold was cut after the hold-break", variant);
        CHECK(gap <= c.holdBreak + 3.0 / fps, "variant %d: game up %.3f s during the hold", variant, gap);
        CHECK(!s.gameDown, "variant %d: button stuck after the hold", variant);
        CHECK(!s.eng.active(), "variant %d still active", variant);
        CHECK(s.violations == 0, "variant %d violations %d", variant, s.violations);
    }
    std::printf("      worst case over 12 phases: %.0f ms before the hold is noticed (hold-break setting: 100 ms)\n",
                worstGapAll * 1000);
}

static void test_side_switch_and_disable() {
    std::printf("[5d] Other player's side / feature switched off mid-spam\n");
    {
        std::mt19937 rng(31);
        Sim s;
        Config c;
        c.activationCps = 8;
        s.eng.setConfig(c);
        auto ev = train(0.2, 12.0, 20, 0.04, 0.0, rng);
        const double t = ev.back().t + 0.03;
        ev.push_back({t, true, false});          // other side pressed
        ev.push_back({t + 0.05, false, false});
        play(s, ev, 240, t + 1.0);
        std::printf("      side switch: active afterwards: %s, violations: %d, last press forwarded: %s\n",
                    s.eng.active() ? "yes" : "no", s.violations, "checked");
        CHECK(!s.eng.active(), "assist still active after the other side was pressed");
        CHECK(s.violations == 0, "violations %d", s.violations);
        CHECK(!s.gameDown, "stuck");
    }
    {
        std::mt19937 rng(32);
        Sim s;
        Config c;
        c.activationCps = 8;
        s.eng.setConfig(c);
        auto ev = train(0.2, 12.0, 40, 0.04, 0.0, rng);
        bool toggled = false;
        double disabledAt = 1.5;
        int deactBefore = 0;
        play(s, ev, 144, 5.0, true, [&](double f) {
            if (!toggled && f >= disabledAt) {
                toggled = true;
                deactBefore = s.deactivations;
                Config d = s.eng.config();
                d.enabled = false;
                s.eng.setConfig(d);
            }
        });
        // after disabling, the remaining clicks (until 0.2 + 40/12 = 3.5 s) must pass through 1:1
        size_t realAfter = 0, gameAfter = 0;
        for (auto const& e : ev)
            if (e.press && e.t > disabledAt + 0.1) ++realAfter;
        for (auto const& g : s.game)
            if (g.down && g.t > disabledAt + 0.1) ++gameAfter;
        std::printf("      disabled at %.1f s: deactivations %d -> %d, presses after: real %zu, game %zu\n", disabledAt,
                    deactBefore, s.deactivations, realAfter, gameAfter);
        CHECK(s.deactivations == deactBefore + 1, "did not deactivate on disable");
        CHECK(realAfter == gameAfter, "presses after disable differ: real %zu game %zu", realAfter, gameAfter);
        CHECK(s.violations == 0, "violations %d", s.violations);
        CHECK(!s.gameDown, "stuck");
    }
}

static void test_reset() {
    std::printf("[5e] Level restart releases an assist-held button\n");
    int releases = 0;
    for (double off = 0.0; off < 0.083; off += 0.004) {
        std::mt19937 rng(41);
        Sim s;
        Config c;
        c.activationCps = 8;
        c.targetCps = 12;
        c.strength = 1.0;
        s.eng.setConfig(c);
        auto ev = train(0.2, 12.0, 20, 0.04, 0.0, rng);
        play(s, ev, 480, 1.5 + off);  // stop at an arbitrary phase of the assist's rhythm
        const bool holding = s.gameDown;
        const auto r = s.eng.reset();
        if (holding) {
            CHECK(r.action == Action::Release, "offset %.3f: holding but reset() returned no release", off);
            ++releases;
        } else {
            CHECK(r.action == Action::None, "offset %.3f: not holding but reset() returned an action", off);
        }
        CHECK(!s.eng.active(), "still active after reset");
        // next real click afterwards behaves like vanilla
        const auto p = s.eng.onRealPress(10.0, true);
        CHECK(p.forward && !p.activated, "first click after reset not passed through");
    }
    std::printf("      reset() released a held assist button in %d of the sampled phases\n", releases);
    CHECK(releases > 0, "never sampled an assist-held phase");
}

// ------------------------------------------------------------------------------------------
// 6. Randomised invariants
// ------------------------------------------------------------------------------------------

static void test_fuzz() {
    std::printf("[6] Randomised invariants (300 seeds x 20 s of mixed input)\n");
    int totalAct = 0;
    int maxViolations = 0;
    double worstDownFingerUpAll = 0;
    int stuck = 0;
    long frames = 0;

    for (int seed = 0; seed < 300; ++seed) {
        std::mt19937 rng(static_cast<unsigned>(seed) * 7919u + 13u);
        auto uni = [&](double a, double b) { return a + (b - a) * (static_cast<double>(rng() % 100000) / 100000.0); };

        const double fpsChoices[] = {30, 45, 60, 90, 120, 144, 240};
        const double fps = fpsChoices[rng() % 7];
        const double dt = 1.0 / fps;

        Config c;
        c.enabled = (rng() % 10) != 0;
        c.activationCps = uni(3, 20);
        c.targetCps = uni(4, 30);
        c.strength = uni(0, 1);
        c.holdBreak = uni(0.06, 0.25);

        // build the script
        std::vector<RealEv> ev;
        double t = 0.1;
        while (t < 20.0) {
            const int kind = static_cast<int>(rng() % 5);
            if (kind <= 1) {  // spam burst
                auto tr = train(t, uni(5, 28), 3 + static_cast<int>(rng() % 40), uni(0.015, 0.07), uni(0, 0.3), rng);
                ev.insert(ev.end(), tr.begin(), tr.end());
                t = tr.back().t + 0.02;
            } else if (kind == 2) {  // hold
                const double d = uni(0.15, 0.9);
                ev.push_back({t, true, true});
                ev.push_back({t + d, false, true});
                t += d + 0.02;
            } else if (kind == 3) {  // single tap
                const double d = uni(0.02, 0.12);
                ev.push_back({t, true, true});
                ev.push_back({t + d, false, true});
                t += d + 0.02;
            }
            t += uni(0.03, 0.9);  // pause
        }

        Sim s;
        s.eng.setConfig(c);
        const bool alwaysDisabled = !c.enabled;
        double worstDownFingerUp = 0;  // per run
        double worstHoldLag = 0;       // per run
        double downWithFingerUpSince = -1;
        std::vector<double> flips;  // config flip times
        for (int i = 0; i < 4; ++i) flips.push_back(uni(1, 18));
        size_t flipIdx = 0;
        std::sort(flips.begin(), flips.end());
        bool disabledForAll = alwaysDisabled;

        play(s, ev, fps, ev.back().t + 1.6, true, [&](double f) {
            ++frames;
            // mid-run config changes (never touching holdBreak so the hold bound below stays valid)
            if (!alwaysDisabled && flipIdx < flips.size() && f >= flips[flipIdx]) {
                ++flipIdx;
                Config n = s.eng.config();
                n.enabled = (rng() % 4) != 0;
                n.activationCps = uni(3, 20);
                n.targetCps = uni(4, 30);
                n.strength = uni(0, 1);
                s.eng.setConfig(n);
                if (!n.enabled) disabledForAll = false;
            }
            // bound 1: the game must not stay down for long while no finger is down
            if (s.gameDown && s.fingers == 0) {
                if (downWithFingerUpSince < 0) downWithFingerUpSince = f;
                worstDownFingerUp = std::max(worstDownFingerUp, f - downWithFingerUpSince);
            } else {
                downWithFingerUpSince = -1;
            }
            // bound 2: a finger held down past the hold-break must be reflected in the game
            if (s.fingers > 0 && s.fingerSince >= 0) {
                const double lag = f - s.fingerSince - s.eng.config().holdBreak;
                if (lag > 2 * dt + 0.01 && !s.gameDown) worstHoldLag = std::max(worstHoldLag, lag);
            }
        });

        maxViolations = std::max(maxViolations, s.violations);
        totalAct += s.activations;
        if (s.gameDown) ++stuck;
        CHECK(s.violations == 0, "seed %d: %d press/release violations (fps %.0f)", seed, s.violations, fps);
        CHECK(!s.gameDown, "seed %d: game button stuck down at the end", seed);
        if (alwaysDisabled || (disabledForAll && s.activations == 0)) {
            size_t inj = 0;
            for (auto const& g : s.game) inj += g.injected ? 1 : 0;
            CHECK(inj == 0, "seed %d: disabled run injected %zu events", seed, inj);
        }
        CHECK(worstDownFingerUp <= 0.045 + 3 * dt + 0.005, "seed %d: game down %.3f s with no finger down (fps %.0f)", seed,
              worstDownFingerUp, fps);
        CHECK(worstHoldLag == 0, "seed %d: finger held past hold-break but game not down (lag %.3f, fps %.0f, holdBreak %.3f)",
              seed, worstHoldLag, fps, c.holdBreak);
        worstDownFingerUpAll = std::max(worstDownFingerUpAll, worstDownFingerUp);
    }
    std::printf("      activations observed: %d, worst press/release violations in one run: %d, runs ending stuck: %d\n",
                totalAct, maxViolations, stuck);
    std::printf("      longest 'game down while no finger down' (any run): %.1f ms\n", worstDownFingerUpAll * 1000);
    CHECK(totalAct > 300, "fuzz barely exercised the assist (%d activations)", totalAct);
}

static void test_multitouch_robustness() {
    std::printf("[6b] Overlapping touches (two-finger tapping) never leave the game stuck\n");
    int stuck = 0;
    int act = 0;
    for (int seed = 0; seed < 200; ++seed) {
        std::mt19937 rng(static_cast<unsigned>(seed) + 1000u);
        auto uni = [&](double a, double b) { return a + (b - a) * (static_cast<double>(rng() % 100000) / 100000.0); };
        Sim s;
        Config c;
        c.activationCps = uni(3, 12);
        c.targetCps = uni(6, 24);
        c.strength = uni(0, 1);
        s.eng.setConfig(c);
        // two fingers alternating with overlap: press A, press B, release A, release B ...
        std::vector<RealEv> ev;
        double t = 0.1;
        const double rate = uni(6, 20);
        for (int i = 0; i < 120; ++i) {
            const double p = 1.0 / rate;
            ev.push_back({t, true, true});
            ev.push_back({t + 0.4 * p, true, true});
            ev.push_back({t + 0.7 * p, false, true});
            ev.push_back({t + 1.1 * p, false, true});
            t += p * uni(0.8, 1.2);
        }
        std::stable_sort(ev.begin(), ev.end(), [](RealEv const& a, RealEv const& b) { return a.t < b.t; });
        play(s, ev, 144, t + 2.0);
        if (s.gameDown) ++stuck;
        act += s.activations;
    }
    std::printf("      runs ending with the game stuck down: %d of 200 (activations seen: %d)\n", stuck, act);
    CHECK(stuck == 0, "%d runs ended stuck", stuck);
}

// ------------------------------------------------------------------------------------------
// 7. Cost
// ------------------------------------------------------------------------------------------

static void test_cost() {
    std::printf("[7] CPU cost of the engine\n");
    using clock = std::chrono::steady_clock;
    {
        Engine e;
        Config c;
        e.setConfig(c);
        const long n = 20000000;
        const auto a = clock::now();
        double acc = 0;
        for (long i = 0; i < n; ++i) acc += static_cast<double>(e.tick(static_cast<double>(i) * 0.004).action != Action::None);
        const auto b = clock::now();
        const double ns = std::chrono::duration<double, std::nano>(b - a).count() / static_cast<double>(n);
        std::printf("      tick() while inactive: %.1f ns/call (sink %.0f)\n", ns, acc);
        CHECK(ns < 200.0, "inactive tick too slow: %.1f ns", ns);
    }
    {
        Engine e;
        Config c;
        c.targetCps = 14;
        c.strength = 1;
        e.setConfig(c);
        double t = 0;
        for (int i = 0; i < 8; ++i) {
            e.onRealPress(t, true);
            e.onRealRelease(t + 0.03);
            t += 0.09;
        }
        const long n = 5000000;
        const auto a = clock::now();
        long acts = 0;
        double next = t;
        for (long i = 0; i < n; ++i) {
            t += 1.0 / 240.0;
            if (t >= next) {  // keep the "player" spamming so the assist stays active
                e.onRealPress(t, true);
                e.onRealRelease(t + 0.001);
                next += 0.09;
            }
            acts += static_cast<long>(e.tick(t).action != Action::None);
        }
        const auto b = clock::now();
        const double ns = std::chrono::duration<double, std::nano>(b - a).count() / static_cast<double>(n);
        std::printf("      tick()+events while active at 240 FPS: %.1f ns/frame (%ld synthetic events)\n", ns, acts);
        CHECK(ns < 2000.0, "active frame too slow: %.1f ns", ns);
        CHECK(acts > 1000, "assist did not stay active during the cost run");
    }
}


// ------------------------------------------------------------------------------------------
// 8. Flow Assist additions
// ------------------------------------------------------------------------------------------

// Frame timestamps with vsync-style noise (each frame lands within +-jitter of a frame of its ideal time).
static std::vector<double> jitteredFrames(double fps, double tEnd, double jitter, std::mt19937& rng) {
    std::vector<double> f;
    std::uniform_real_distribution<double> u(-jitter, jitter);
    const double fd = 1.0 / fps;
    for (long k = 0;; ++k) {
        const double t = static_cast<double>(k) * fd + (k == 0 ? 0.0 : u(rng) * fd);
        if (t > tEnd) break;
        f.push_back(t);
    }
    return f;
}

static void playFrames(Sim& s, std::vector<RealEv> const& evs, std::vector<double> const& frames) {
    size_t i = 0;
    for (double f : frames) {
        while (i < evs.size() && evs[i].t <= f + 1e-12) {
            if (evs[i].press) s.press(f, evs[i].p1);
            else s.release(f, evs[i].p1);
            ++i;
        }
        s.tick(f);
    }
}

// Two fingers taking turns: every press lands while the other finger is still down.
static void test_two_finger_alternation() {
    std::printf("[8a] Two-finger alternation (overlapping presses) must not be mistaken for a hold\n");
    for (double rate : {9.0, 12.0, 16.0}) {
        for (double fps : {60.0, 144.0}) {
            std::mt19937 rng(21);
            std::uniform_real_distribution<double> u(-0.1, 0.1);
            Sim s;
            Config c;
            c.activationCps = 8;
            c.targetCps = rate + 2;
            c.strength = 0.6;
            s.eng.setConfig(c);
            std::vector<RealEv> ev;
            double t = 0.3;
            for (int i = 0; i < 60; ++i) {
                const double interval = (1.0 / rate) * (1.0 + u(rng));
                ev.push_back({t, true, true});
                ev.push_back({t + 1.2 * interval, false, true});
                t += interval;
            }
            std::stable_sort(ev.begin(), ev.end(), [](RealEv const& a, RealEv const& b) { return a.t < b.t; });
            const double tStop = ev.back().t;
            play(s, ev, fps, tStop + 1.0);
            Sim raw;                       // the same input with the assist off: its own overlapped presses count as
            Config off;                    // "press while down" in the game stream, and nothing the assist does may add to that
            off.enabled = false;
            raw.eng.setConfig(off);
            play(raw, ev, fps, tStop + 1.0);
            std::printf("      %4.1f CPS @ %3.0f FPS: activations %d, deactivations %d, released at the end: %s\n", rate, fps,
                        s.activations, s.deactivations, s.gameDown ? "NO" : "yes");
            CHECK(s.activations == 1, "rate %.0f fps %.0f activations %d", rate, fps, s.activations);
            CHECK(s.deactivations <= 1, "rate %.0f fps %.0f deactivations %d", rate, fps, s.deactivations);
            CHECK(!s.gameDown, "game button stuck down");
            CHECK(s.violations <= raw.violations, "violations %d vs %d without the assist", s.violations, raw.violations);
        }
    }
}

static void test_frame_aware_output() {
    std::printf("[8b] Output rhythm is steady and every press has the same length (noisy frame times)\n");
    for (double fps : {60.0, 120.0, 144.0}) {
        // 12 CPS lands on a whole number of frames at all three rates; it is exactly the case where frame-time
        // noise used to flip single clicks between two neighbouring frames.
        std::mt19937 rng(77);
        Sim s;
        Config c;
        c.activationCps = 8;
        c.targetCps = 12;
        c.strength = 1.0;
        s.eng.setConfig(c);
        auto ev = train(0.2, 9.0, 50, 0.045, 0.0, rng);
        playFrames(s, ev, jitteredFrames(fps, 6.0, 0.08, rng));
        const auto p = pressTimes(s, 1.5, 4.5);
        std::vector<double> lengths;
        for (size_t i = 0; i + 1 < s.game.size(); ++i)
            if (s.game[i].down && s.game[i].injected && !s.game[i + 1].down && s.game[i].t >= 1.5 && s.game[i].t < 4.5)
                lengths.push_back(s.game[i + 1].t - s.game[i].t);
        std::vector<int> frames;
        for (double w : lengths) frames.push_back(static_cast<int>(std::lround(w * fps)));
        const bool allSame = !frames.empty() && std::all_of(frames.begin(), frames.end(), [&](int f) { return f == frames[0]; });
        std::printf("      %4.0f FPS: interval CV %.3f, %zu presses, press length %d frame(s) %s\n", fps, cv(p), lengths.size(),
                    frames.empty() ? 0 : frames[0], allSame ? "for every press" : "VARIES");
        CHECK(cv(p) < 0.03, "fps %.0f interval CV %.4f", fps, cv(p));
        CHECK(allSame, "fps %.0f press length varies", fps);
        CHECK(s.violations == 0, "violations %d", s.violations);
    }
}

static void test_side_aware_release() {
    std::printf("[8c] Another player's release is never swallowed (dual mode, split touch)\n");
    Engine e;
    Config c;
    c.activationCps = 8;
    e.setConfig(c);
    // player 2's finger goes down and stays there, player 1 spams until the assist is active
    e.onRealPress(0.05, false);
    double t = 0.2;
    bool active = false;
    for (int i = 0; i < 8 && !active; ++i, t += 0.08) {
        const auto r = e.onRealPress(t, true);
        e.onRealRelease(t + 0.03, true);
        active = r.activated || e.active();
    }
    CHECK(e.active(), "assist should be active for player 1");
    const auto rel2 = e.onRealRelease(t + 0.01, false);
    CHECK(rel2.forward, "player 2's release was swallowed");
    CHECK(e.active(), "player 2's release must not end player 1's assist");
    const auto rel2again = e.onRealRelease(t + 0.02, false);   // nothing is down on that side any more
    CHECK(rel2again.forward, "stray release was swallowed");
    // and player 1's own release is still the assist's to swallow
    e.onRealPress(t + 0.05, true);
    const auto rel1 = e.onRealRelease(t + 0.08, true);
    CHECK(!rel1.forward, "player 1's release should still be swallowed while assisting");
    std::printf("      player 2 release forwarded: %s, assist still active: %s\n", rel2.forward ? "yes" : "NO", e.active() ? "yes" : "NO");
}

static void test_unexpected_release() {
    std::printf("[8d] A release nobody expected is passed on, never swallowed\n");
    Sim s;
    Config c;
    c.activationCps = 8;
    s.eng.setConfig(c);
    std::mt19937 rng(5);
    auto ev = train(0.2, 12.0, 8, 0.04, 0.0, rng);
    play(s, ev, 120, ev.back().t + 0.01);
    CHECK(s.eng.active(), "assist should be active");
    CHECK(s.fingers == 0, "finger should be up");
    const auto r = s.eng.onRealRelease(ev.back().t + 0.02, true);
    CHECK(r.forward, "unexpected release was swallowed");
    CHECK(s.eng.active(), "outside co-op mode an unexpected release must not stop the assist");
    CHECK(s.eng.foreign() == 1, "foreign count %u", s.eng.foreign());
    std::printf("      forwarded: %s, assist still active (not in co-op mode): %s\n", r.forward ? "yes" : "NO", s.eng.active() ? "yes" : "NO");
}

static void test_coop_backoff() {
    std::printf("[8e] Co-op mode (Afterflow, 'Share'): back off on input that was re-sent behind our back\n");
    Engine e;
    Config c;
    c.activationCps = 8;
    c.coop = true;
    e.setConfig(c);
    auto spam = [&](double from, int n) {
        double t = from;
        for (int i = 0; i < n; ++i, t += 0.08) {
            e.onRealPress(t, true);
            e.onRealRelease(t + 0.03, true);
            e.tick(t + 0.04);
        }
        return t;
    };
    double t = spam(0.2, 8);
    CHECK(e.active(), "should be active before the foreign release");
    const auto r = e.onRealRelease(t + 0.001, true);     // no finger down: not the player's
    CHECK(r.forward, "foreign release must be forwarded");
    CHECK(!e.active(), "co-op mode must stop owning the button");
    CHECK(e.foreign() == 1, "foreign %u", e.foreign());
    // it stays out of the way for a while even though the player keeps spamming
    t = spam(t + 0.1, 12);
    CHECK(!e.active(), "must not re-activate during the cool-down");
    // after the cool-down it may work again
    t = spam(t + 2.2, 10);
    CHECK(e.active(), "should be allowed again after the cool-down");
    // two more foreign events lock it out for the rest of the level
    e.onRealRelease(t + 0.001, true);
    t = spam(t + 2.3, 10);
    e.onRealRelease(t + 0.001, true);
    CHECK(e.lockedOut(), "three foreign events should lock the assist out");
    t = spam(t + 3.0, 14);
    CHECK(!e.active(), "locked out: must stay inactive");
    e.reset(/*newLevel=*/true);
    CHECK(!e.lockedOut(), "a new level clears the lock-out");
    std::printf("      backed off, cooled down, locked out after 3 events, cleared on new level: ok\n");
}

// Model of a mod that holds some input back and re-delivers it later through the SAME entry point
// (GJBaseGameLayer::handleButton), which is the pattern a predictive input buffer such as Afterflow uses.
// This is a model of that pattern only, not Afterflow's code.
struct Pipe {
    struct Held { double due; bool down; };
    Engine eng;
    std::vector<GameEv> game;
    std::vector<Held> q;
    bool gameDown = false;
    int fingers = 0;
    bool afterflow = true;

    static unsigned h(unsigned x) { x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x; }

    void toGame(double t, bool down, bool injected) {
        gameDown = down;
        game.push_back({t, down, injected});
    }
    // entry point of the "predictive buffer": hold some events back, deliver the rest
    void afterflowIn(double t, bool down, bool injected, bool redelivery) {
        if (!afterflow || redelivery) return toGame(t, down, injected);
        if (!q.empty()) {                                            // keep order: queue behind what is waiting
            q.push_back({q.back().due + 0.002, down});
            return;
        }
        const unsigned k = h(static_cast<unsigned>(t * 240.0) * 2U + (down ? 1U : 0U));
        if (k % 4U == 0U) q.push_back({t + (1.0 + static_cast<double>(k / 4U % 40U)) / 240.0, down});   // 1..40 ticks
        else toGame(t, down, injected);
    }
    // our hook (outer) sees every event, real, injected or re-delivered
    void hookPress(double t, bool injected, bool redelivery) {
        if (injected) return afterflowIn(t, true, true, redelivery);
        const auto r = eng.onRealPress(t, true);
        if (r.preRelease) afterflowIn(t, false, true, false);
        if (r.forward) afterflowIn(t, true, false, redelivery);
    }
    void hookRelease(double t, bool injected, bool redelivery) {
        if (injected) return afterflowIn(t, false, true, redelivery);
        const auto r = eng.onRealRelease(t, true);
        if (r.forward) afterflowIn(t, false, false, redelivery);
    }
    void realPress(double t) { ++fingers; hookPress(t, false, false); }
    void realRelease(double t) { if (fingers > 0) --fingers; hookRelease(t, false, false); }
    void frame(double t) {
        // re-deliveries happen inside the game's step loop, before our per-frame tick
        while (!q.empty() && q.front().due <= t) {
            const Held e = q.front();
            q.erase(q.begin());
            if (e.down) hookPress(t, false, true);
            else hookRelease(t, false, true);
        }
        const auto o = eng.tick(t);
        if (o.action == Action::Press) hookPress(t, true, false);
        else if (o.action == Action::Release) hookRelease(t, true, false);
    }
};

static void runPipe(Pipe& p, std::vector<RealEv> const& evs, double fps, double tEnd) {
    size_t i = 0;
    const double dt = 1.0 / fps;
    for (long k = 0;; ++k) {
        const double f = static_cast<double>(k) * dt;
        if (f > tEnd) break;
        while (i < evs.size() && evs[i].t <= f + 1e-12) {
            if (evs[i].press) p.realPress(f);
            else p.realRelease(f);
            ++i;
        }
        p.frame(f);
    }
}

static std::vector<RealEv> spamAndHold(std::mt19937& rng) {
    auto ev = train(0.2, 11.0, 30, 0.04, 0.12, rng);
    ev.push_back({ev.back().t + 0.25, true, true});          // then a real hold
    ev.push_back({ev.back().t + 0.6, false, true});
    auto more = train(ev.back().t + 0.4, 12.0, 20, 0.04, 0.12, rng);
    ev.insert(ev.end(), more.begin(), more.end());
    return ev;
}

static void test_afterflow_yield_is_transparent() {
    std::printf("[8f] Yielding to Afterflow is exactly as if Flow Assist were not installed\n");
    for (int seed = 0; seed < 12; ++seed) {
        std::mt19937 rng1(static_cast<unsigned>(300 + seed)), rng2(static_cast<unsigned>(300 + seed));
        const auto ev1 = spamAndHold(rng1);
        const auto ev2 = spamAndHold(rng2);
        Pipe off, yield;
        Config c;
        c.activationCps = 8;
        c.enabled = false;
        off.eng.setConfig(c);
        c.enabled = true;
        c.yielding = true;
        yield.eng.setConfig(c);
        const double tEnd = ev1.back().t + 1.0;
        runPipe(off, ev1, 144, tEnd);
        runPipe(yield, ev2, 144, tEnd);
        bool same = off.game.size() == yield.game.size();
        for (size_t i = 0; same && i < off.game.size(); ++i)
            same = off.game[i].down == yield.game[i].down && std::fabs(off.game[i].t - yield.game[i].t) < 1e-12 &&
                   off.game[i].injected == yield.game[i].injected;
        size_t injected = 0;
        for (auto const& g : yield.game) injected += g.injected ? 1 : 0;
        CHECK(same, "seed %d: game stream differs from the one without Flow Assist (%zu vs %zu events)", seed, off.game.size(),
              yield.game.size());
        CHECK(injected == 0, "seed %d: yielding mode injected %zu events", seed, injected);
        CHECK(!yield.eng.active(), "seed %d: assist active while yielding", seed);
        if (seed == 0)
            std::printf("      %zu game events with Afterflow-style hold-back and re-delivery, identical: %s, injected by Flow Assist: %zu\n",
                        yield.game.size(), same ? "yes" : "NO", injected);
    }
}

static void test_afterflow_share_stays_consistent() {
    std::printf("[8g] 'Share' with Afterflow-style re-delivery: no stuck button, backs off instead of fighting\n");
    int backedOff = 0, stuck = 0, runs = 0;
    for (int seed = 0; seed < 200; ++seed) {
        const double fps = (seed % 2 == 0) ? 144.0 : 60.0;
        std::mt19937 rng(static_cast<unsigned>(900 + seed));
        const auto ev = spamAndHold(rng);
        Pipe p;
        Config c;
        c.activationCps = 8;
        c.targetCps = 13;
        c.coop = true;
        p.eng.setConfig(c);
        runPipe(p, ev, fps, ev.back().t + 1.5);
        ++runs;
        if (p.gameDown) ++stuck;
        if (p.eng.foreign() > 0) ++backedOff;
        CHECK(!p.gameDown, "seed %d: game button stuck down at the end", seed);
        CHECK(!p.eng.active(), "seed %d: still active after the player stopped", seed);
    }
    std::printf("      %d runs: %d ended stuck, the assist backed off in %d of them\n", runs, stuck, backedOff);
}

int main() {
    test_cps_accuracy();
    test_activation_threshold();
    test_no_activation_from_lone_click();
    test_passthrough();
    test_assist_rate();
    test_rhythm_consistency();
    test_stops_when_player_stops();
    test_slows_down();
    test_hold_handover();
    test_side_switch_and_disable();
    test_reset();
    test_fuzz();
    test_multitouch_robustness();
    test_cost();
    test_two_finger_alternation();
    test_frame_aware_output();
    test_side_aware_release();
    test_unexpected_release();
    test_coop_backoff();
    test_afterflow_yield_is_transparent();
    test_afterflow_share_stays_consistent();

    std::printf("\n%d checks, %d failed\n", g_checks, g_failed);
    return g_failed == 0 ? 0 : 1;
}
