# Flow Assist 1.2.0 - build and test report

Developer **Lumin**, mod **Flow Assist**, id `lumin.flow-assist`. Built on the supplied v1.1.0 source, with the
supplied Alternate Assist source and the Voidius `.geode` as the behavioural reference.

## 1. Real Geode builds - NOT DONE (blocker)

| Target | Result |
|---|---|
| Windows x64 `.geode` | **Not built.** |
| Android ARM64 `.geode` | **Not built.** |

Blocker: the sandbox has no network and none of Geode SDK, Android NDK, clang / clang-cl / MSVC, cmake, ninja
(only g++ 13.3, make, python3, ffmpeg). The workflow `.github/workflows/build.yml` builds both targets on GitHub.
Everything that touches the Geode SDK (`Hooks.cpp`, `Shared.cpp`, `Hud.cpp`, `SettingWidgets.cpp`) is therefore
**uncompiled against the real SDK**. New Geode-facing code reuses the member names and call shapes of Alternate
Assist's `main.cpp` (`processCommands`, `m_gameState.m_currentProgress`, `m_isShip/m_isDart/m_isBird/m_isSwing/
m_isUpsideDown`, `m_queuedButtons`, `m_timestamp`), which compiled for that mod.

## 2. Inspection findings

* `prsevend_voidius.geode` (Voidius, Windows `.dll`) is **Alternate Assist v1.6.1 rebuilt**: identical resources, same
  `mod.json` apart from id / name / panel key. Its Go Straight behaviour is therefore the `Leveler` in
  `alternate-assist-source.zip`. Only its metadata and resources were inspected; its binary was not decompiled.
* Flow Assist v1.1.0 had **no Go Straight at all** and produced clicks per frame, not per physics tick. That is why it
  could not match the straightness of Voidius.
* v1.1.0 `logo.png` was **not your logo** (blue rings icon). Replaced with your supplied image.
* `lumin_flow-assist.geode` contains only an `android64` binary and a `mod.json` identical to the v1.1.0 source.
* The Voidius law has a flaw on the swing model: it flips "whenever moving away", even when gravity already pulls the
  player back, so the simulated swing diverges. Predictive swing measures gravity's direction instead.
* Video `oJ1juGdLU1YvyhdHEs8MEg.mp4` (1244x720, 60 fps, 4.7 s) was viewed as frames: a ship holding a flat line through a
  spike corridor, then a cube section. **A pixel tracker for ship height was tried and abandoned** (the rainbow
  background confounded it), so no height measurement from the video exists. Straightness numbers come from
  simulation only.

## 3. Changes

`src/TickDrive.hpp` (new: tick rhythm + Predictive/Classic leveler), `src/TickDriver.hpp` (new: per-tick glue),
`src/AssistEngine.hpp` (external-drive API; frame path unchanged), `src/Hooks.cpp` (+`processCommands`),
`src/Shared.*` (Go Straight settings, tick-stamped injection), `src/Hud.cpp`, `src/SettingWidgets.cpp` (`STRAIGHT`),
`src/Defaults.hpp`, `mod.json` (6 settings, v1.2.0), `logo.png` + `branding/`, CI workflow, docs, tests.
Diff of `src/`: `reports/changes_vs_v1.1.0_src.diff`.

## 4. Standalone checks - RUN

| Check | Result |
|---|---|
| `tests/engine_test.cpp` (existing), `-Wall -Wextra -Werror` | 1969 checks, 0 failed |
| same, `-fsanitize=address,undefined` | 1969 checks, 0 failed, no reports |
| `tests/straight_test.cpp` (new), `-Wall -Wextra -Werror` | 185 checks, 0 failed |
| same, `-fsanitize=address,undefined` | 185 checks, 0 failed, no reports |
| `tests/compare_test.cpp` | runs; output in `reports/` |
| `tools/check_defaults.py` | OK: 22 settings, 28 code references, identity Flow Assist / Lumin / lumin.flow-assist |
| `tools/syntax_check.sh` | OK, against **hand-written stand-in headers only** |

What `straight_test.cpp` covers: tick rhythm accuracy, no bursts after lag; Classic law identical to the Voidius law
action-for-action on 138 runs; Predictive vs Voidius law on simulated ship/wave/UFO/swing plants (numbers in README);
click limit never exceeded; determinism; extreme CPS limits (2 and 60); fallback to Classic before learning and on
implausible plants; teleport and gravity-flip recovery; engine + driver in a game loop (activation, hand-back, hold,
gamemode change, restart, no double or stuck events); plain-rhythm timing, v1.1.0 frame path vs tick grid at 60 and 144 FPS.

## 5. Not verified

* Any behaviour inside Geometry Dash, on either platform, alone or with Afterflow.
* That the real ship / UFO / swing physics match the simulated plants. Predictive may need tuning on real data; Classic
  is one setting away.
* That the new `processCommands` hook coexists with Afterflow's hooks (Yield makes it inert; Share untested).
* Icon display in Geode (the file is the correct 336x336 `logo.png` and Geode packages it from the project root).
