# v1.2.0

- **Official logo**: `logo.png` is now the Flow Assist logo you supplied (purple fast-forward icon). v1.1.0 shipped a different image.
- **Go Straight** (ship, wave, UFO, swing): while the assist is active it holds the height you were at when it took over instead of clicking a fixed rhythm that drifts. New settings: Go Straight, Straight Engine (Predictive / Classic), Ship / Wave / UFO / Swing CPS.
- **Predictive engine**: measures how hard the button pushes the player and switches where the player would come to rest. **Classic** is the original Alternate Assist / Voidius law, kept as a one-setting fallback.
- **240 Hz tick-grid clicks**: all assisted clicks now land on the game's physics ticks (new `processCommands` hook), instead of on frame boundaries. Worst click timing error at 14 CPS, 60 FPS: 11.9 ms -> 3.6 ms.
- HUD / settings status show `STRAIGHT` while flying level.
- Afterflow Yield / Share behaviour unchanged (Yield never touches input).

# v1.1.0

- Renamed to **Flow Assist** (developer **Lumin**, id `lumin.flow-assist`). Continues Alternate Assist; settings from the old id do not carry over.
- Straighter output: presses land on the frame nearest their ideal time and every press has the same length in frames.
- Two-finger alternation (overlapping presses) no longer counts as a hold, so the assist stays on.
- The other player's release is never swallowed; releases nobody expected are passed on.
- Afterflow coexistence: new **Afterflow Mode** setting (Yield by default, or experimental Share), `AFTERFLOW` status in the HUD and settings page.
- Less work per frame while the assist is active.
- Fixed the GitHub Actions workflow (invalid expression syntax) and extended CI with sanitizer and comparison runs.

# v1.0.0 (as Alternate Assist)

- Initial release.
- CPS detection, threshold-activated click assist, assistance strength and target CPS.
- Settings page with live CPS counter + tap pad, status indicator and reset button.
- In-level HUD with an activation pulse.
